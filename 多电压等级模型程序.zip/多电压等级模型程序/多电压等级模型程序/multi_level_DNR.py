# 智能体数量为5个，包括高压侧智能体1个，低压侧智能体2个和变电站智能体2个

import os
import pickle
import power as PW
import OLTC_Mask as OM
import MISOCP重构 as RE
import switch_pairs_Mask as SPM
import pandas as pd
import scipy.io as sio
import random
import itertools
import collections
import numpy as np
from tqdm import tqdm
import torch
import torch.nn.functional as F
import copy
from torch.distributions import Normal
import matplotlib.pyplot as plt
from tensorboardX import SummaryWriter

random.seed(0)
np.random.seed(0)
torch.manual_seed(0)

class PolicyNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, action_dim):
        super(PolicyNet, self).__init__()
        self.fc1 = torch.nn.Linear(state_dim, hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = torch.nn.Linear(hidden_dim, action_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return F.softmax(self.fc3(x), dim=1)

class QValueNet(torch.nn.Module):    #输出动作的价值
    ''' 只有一层隐藏层的Q网络 '''
    def __init__(self, state_dim, hidden_dim, action_dim):
        super(QValueNet, self).__init__()
        self.fc1 = torch.nn.Linear(state_dim, hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim,hidden_dim)
        self.fc3 = torch.nn.Linear(hidden_dim, action_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)

class SAC:
    ''' 处理离散动作的SAC算法 '''
    def __init__(self, hidden_dim, state_dim_HV, action_dim_HV, state_dim_MV1, action_dim_MV1,state_dim_MV2, action_dim_MV2,
                 state_dim_OLTCL, action_dim_OLTCL,state_dim_OLTCR, action_dim_OLTCR,actor_lr, critic_lr, alpha_lr,target_entropy,
                 tau,gamma,MEMORY_CAPACITY, script_name_HV,script_name_MV1,script_name_MV2,script_name_OLTCL,script_name_OLTCR, device):

        ##################### 其他一些参数设置 #####################
        self.target_entropy = target_entropy  # 目标熵的大小
        self.gamma = gamma
        self.tau = tau
        self.device = device
        self.memory_counter = 0
        self.MEMORY_CAPACITY = MEMORY_CAPACITY
        self.memory = np.zeros((MEMORY_CAPACITY, (state_dim_HV *2 +2)+(state_dim_MV1 *2 +2)+(state_dim_MV2 *2 +2)+
                                (state_dim_OLTCL *2 +2)+(state_dim_OLTCR *2 +2)))

        ##################### Agent-HV #####################
        # 策略网络
        self.state_dim_HV = state_dim_HV
        self.action_dim_HV = action_dim_HV
        self.actor_HV = PolicyNet(state_dim_HV, hidden_dim, action_dim_HV).to(device)
        # 第一个Q网络
        self.critic_1_HV = QValueNet(state_dim_HV, hidden_dim, action_dim_HV).to(device)
        # 第二个Q网络
        self.critic_2_HV = QValueNet(state_dim_HV, hidden_dim, action_dim_HV).to(device)
        self.target_critic_1_HV = QValueNet(state_dim_HV, hidden_dim,action_dim_HV).to(device)  # 第一个目标Q网络
        self.target_critic_2_HV = QValueNet(state_dim_HV, hidden_dim,action_dim_HV).to(device)  # 第二个目标Q网络
        # 令目标Q网络的初始参数和Q网络一样
        self.target_critic_1_HV.load_state_dict(self.critic_1_HV.state_dict())
        self.target_critic_2_HV.load_state_dict(self.critic_2_HV.state_dict())
        self.actor_optimizer_HV = torch.optim.Adam(self.actor_HV.parameters(),lr=actor_lr)
        self.critic_1_optimizer_HV = torch.optim.Adam(self.critic_1_HV.parameters(),lr=critic_lr)
        self.critic_2_optimizer_HV = torch.optim.Adam(self.critic_2_HV.parameters(),lr=critic_lr)
        # 使用alpha的log值,可以使训练结果比较稳定
        self.log_alpha_HV = torch.tensor(np.log(0.01), dtype=torch.float)
        self.log_alpha_HV.requires_grad = True  # 可以对alpha求梯度
        self.log_alpha_optimizer_HV = torch.optim.Adam([self.log_alpha_HV],lr=alpha_lr)
        # 其他
        self.script_name_HV = script_name_HV
        self.directory_HV = './exp' + self.script_name_HV + '/'
        self.writer_HV = SummaryWriter(self.directory_HV)

        ##################### Agent-MV1 #####################
        # 策略网络
        self.state_dim_MV1 = state_dim_MV1
        self.action_dim_MV1 = action_dim_MV1
        self.actor_MV1 = PolicyNet(state_dim_MV1, hidden_dim, action_dim_MV1).to(device)
        # 第一个Q网络
        self.critic_1_MV1 = QValueNet(state_dim_MV1, hidden_dim, action_dim_MV1).to(device)
        # 第二个Q网络
        self.critic_2_MV1 = QValueNet(state_dim_MV1, hidden_dim, action_dim_MV1).to(device)
        self.target_critic_1_MV1 = QValueNet(state_dim_MV1, hidden_dim, action_dim_MV1).to(device)  # 第一个目标Q网络
        self.target_critic_2_MV1 = QValueNet(state_dim_MV1, hidden_dim, action_dim_MV1).to(device)  # 第二个目标Q网络
        # 令目标Q网络的初始参数和Q网络一样
        self.target_critic_1_MV1.load_state_dict(self.critic_1_MV1.state_dict())
        self.target_critic_2_MV1.load_state_dict(self.critic_2_MV1.state_dict())
        self.actor_optimizer_MV1 = torch.optim.Adam(self.actor_MV1.parameters(), lr=actor_lr)
        self.critic_1_optimizer_MV1 = torch.optim.Adam(self.critic_1_MV1.parameters(), lr=critic_lr)
        self.critic_2_optimizer_MV1 = torch.optim.Adam(self.critic_2_MV1.parameters(), lr=critic_lr)
        # 使用alpha的log值,可以使训练结果比较稳定
        self.log_alpha_MV1 = torch.tensor(np.log(0.01), dtype=torch.float)
        self.log_alpha_MV1.requires_grad = True  # 可以对alpha求梯度
        self.log_alpha_optimizer_MV1 = torch.optim.Adam([self.log_alpha_MV1], lr=alpha_lr)
        # 其他
        self.script_name_MV1 = script_name_MV1
        self.directory_MV1 = './exp' + self.script_name_MV1 + '/'
        self.writer_MV1 = SummaryWriter(self.directory_MV1)

        ##################### Agent-MV2 #####################
        # 策略网络
        self.state_dim_MV2 = state_dim_MV2
        self.action_dim_MV2 = action_dim_MV2
        self.actor_MV2 = PolicyNet(state_dim_MV2, hidden_dim, action_dim_MV2).to(device)
        # 第一个Q网络
        self.critic_1_MV2 = QValueNet(state_dim_MV2, hidden_dim, action_dim_MV2).to(device)
        # 第二个Q网络
        self.critic_2_MV2 = QValueNet(state_dim_MV2, hidden_dim, action_dim_MV2).to(device)
        self.target_critic_1_MV2 = QValueNet(state_dim_MV2, hidden_dim, action_dim_MV2).to(device)  # 第一个目标Q网络
        self.target_critic_2_MV2 = QValueNet(state_dim_MV2, hidden_dim, action_dim_MV2).to(device)  # 第二个目标Q网络
        # 令目标Q网络的初始参数和Q网络一样
        self.target_critic_1_MV2.load_state_dict(self.critic_1_MV2.state_dict())
        self.target_critic_2_MV2.load_state_dict(self.critic_2_MV2.state_dict())
        self.actor_optimizer_MV2 = torch.optim.Adam(self.actor_MV2.parameters(), lr=actor_lr)
        self.critic_1_optimizer_MV2 = torch.optim.Adam(self.critic_1_MV2.parameters(), lr=critic_lr)
        self.critic_2_optimizer_MV2 = torch.optim.Adam(self.critic_2_MV2.parameters(), lr=critic_lr)
        # 使用alpha的log值,可以使训练结果比较稳定
        self.log_alpha_MV2 = torch.tensor(np.log(0.01), dtype=torch.float)
        self.log_alpha_MV2.requires_grad = True  # 可以对alpha求梯度
        self.log_alpha_optimizer_MV2 = torch.optim.Adam([self.log_alpha_MV2], lr=alpha_lr)
        # 其他
        self.script_name_MV2 = script_name_MV2
        self.directory_MV2 = './exp' + self.script_name_MV2 + '/'
        self.writer_MV2 = SummaryWriter(self.directory_MV2)

        ##################### Agent-OLTCL #####################
        # 策略网络
        self.state_dim_OLTCL = state_dim_OLTCL
        self.action_dim_OLTCL = action_dim_OLTCL
        self.actor_OLTCL = PolicyNet(state_dim_OLTCL, hidden_dim, action_dim_OLTCL).to(device)
        # 第一个Q网络
        self.critic_1_OLTCL = QValueNet(state_dim_OLTCL, hidden_dim, action_dim_OLTCL).to(device)
        # 第二个Q网络
        self.critic_2_OLTCL = QValueNet(state_dim_OLTCL, hidden_dim, action_dim_OLTCL).to(device)
        self.target_critic_1_OLTCL = QValueNet(state_dim_OLTCL, hidden_dim, action_dim_OLTCL).to(device)  # 第一个目标Q网络
        self.target_critic_2_OLTCL = QValueNet(state_dim_OLTCL, hidden_dim, action_dim_OLTCL).to(device)  # 第二个目标Q网络
        # 令目标Q网络的初始参数和Q网络一样
        self.target_critic_1_OLTCL.load_state_dict(self.critic_1_OLTCL.state_dict())
        self.target_critic_2_OLTCL.load_state_dict(self.critic_2_OLTCL.state_dict())
        self.actor_optimizer_OLTCL = torch.optim.Adam(self.actor_OLTCL.parameters(), lr=actor_lr)
        self.critic_1_optimizer_OLTCL = torch.optim.Adam(self.critic_1_OLTCL.parameters(), lr=critic_lr)
        self.critic_2_optimizer_OLTCL = torch.optim.Adam(self.critic_2_OLTCL.parameters(), lr=critic_lr)
        # 使用alpha的log值,可以使训练结果比较稳定
        self.log_alpha_OLTCL = torch.tensor(np.log(0.01), dtype=torch.float)
        self.log_alpha_OLTCL.requires_grad = True  # 可以对alpha求梯度
        self.log_alpha_optimizer_OLTCL = torch.optim.Adam([self.log_alpha_OLTCL], lr=alpha_lr)
        # 其他
        self.script_name_OLTCL = script_name_OLTCL
        self.directory_OLTCL = './exp' + self.script_name_OLTCL + '/'
        self.writer_OLTCL = SummaryWriter(self.directory_OLTCL)

        ##################### Agent-OLTCR #####################
        # 策略网络
        self.state_dim_OLTCR = state_dim_OLTCR
        self.action_dim_OLTCR = action_dim_OLTCR
        self.actor_OLTCR = PolicyNet(state_dim_OLTCR, hidden_dim, action_dim_OLTCR).to(device)
        # 第一个Q网络
        self.critic_1_OLTCR = QValueNet(state_dim_OLTCR, hidden_dim, action_dim_OLTCR).to(device)
        # 第二个Q网络
        self.critic_2_OLTCR = QValueNet(state_dim_OLTCR, hidden_dim, action_dim_OLTCR).to(device)
        self.target_critic_1_OLTCR = QValueNet(state_dim_OLTCR, hidden_dim, action_dim_OLTCR).to(device)  # 第一个目标Q网络
        self.target_critic_2_OLTCR = QValueNet(state_dim_OLTCR, hidden_dim, action_dim_OLTCR).to(device)  # 第二个目标Q网络
        # 令目标Q网络的初始参数和Q网络一样
        self.target_critic_1_OLTCR.load_state_dict(self.critic_1_OLTCR.state_dict())
        self.target_critic_2_OLTCR.load_state_dict(self.critic_2_OLTCR.state_dict())
        self.actor_optimizer_OLTCR = torch.optim.Adam(self.actor_OLTCR.parameters(), lr=actor_lr)
        self.critic_1_optimizer_OLTCR = torch.optim.Adam(self.critic_1_OLTCR.parameters(), lr=critic_lr)
        self.critic_2_optimizer_OLTCR = torch.optim.Adam(self.critic_2_OLTCR.parameters(), lr=critic_lr)
        # 使用alpha的log值,可以使训练结果比较稳定
        self.log_alpha_OLTCR = torch.tensor(np.log(0.01), dtype=torch.float)
        self.log_alpha_OLTCR.requires_grad = True  # 可以对alpha求梯度
        self.log_alpha_optimizer_OLTCR = torch.optim.Adam([self.log_alpha_OLTCR], lr=alpha_lr)
        # 其他
        self.script_name_OLTCR = script_name_OLTCR
        self.directory_OLTCR = './exp' + self.script_name_OLTCR + '/'
        self.writer_OLTCR = SummaryWriter(self.directory_OLTCR)

    def apply_mask(self, probs, switch_mask):
        # 将 probs 展平为一维向量
        probs = probs.view(-1)  # 形状变为 [2013,]
        # 创建 switch_mask 和 OLTC_mask 的布尔掩码
        switch_mask = switch_mask.view(-1).to(torch.bool)  # 转换为布尔型
        masked_probs = probs * switch_mask.float()
        # 去除负值
        masked_probs = torch.clamp(masked_probs, min=0)
        # 重新归一化概率分布
        if masked_probs.sum() > 0:
            masked_probs = masked_probs / (masked_probs.sum() + 1e-15)  # 防止除以零
        else:
            masked_probs = torch.ones_like(masked_probs) / masked_probs.numel()
        return masked_probs

    def take_action_switch(self, state,current_edges, switch_pairs, flexible_list,feeder_list):
        switch_mask = SPM.switch_pairs_Mask_main(current_edges, switch_pairs, flexible_list,feeder_list)
        switch_mask = torch.tensor(switch_mask, dtype=torch.float32).to(self.device)
        state = state.to(self.device)
        if(state.size()[1]==HV_state.size()[1]):
            probs = self.actor_HV(state)
        if (state.size()[1] == MV1_state.size()[1]):
            probs = self.actor_MV1(state)
        if (state.size()[1] == MV2_state.size()[1]):
            probs = self.actor_MV2(state)

        masked_probs = self.apply_mask(probs, switch_mask).to(torch.float32).to(self.device)
        if masked_probs.sum() > 0:
            masked_probs = masked_probs / (masked_probs.sum() + 1e-15)  # 防止除以零
        else:
            # 如果所有值为零，则使用均匀分布
            masked_probs = torch.ones_like(masked_probs) / masked_probs.numel()

        masked_probs = masked_probs.squeeze()  # 变成 (n,)
        # print(masked_probs)
        action_dist = torch.distributions.Categorical(masked_probs)
        action = action_dist.sample()
        return action.item()         #策略网络输出

    def take_action_OLTC(self, state):
        state = state.to(self.device)
        if (state.size()[1] == OLTCL_state.size()[1]):
            probs = self.actor_OLTCL(state)
        elif (state.size()[1] == OLTCR_state.size()[1]):
            probs = self.actor_OLTCR(state)

        if probs.sum() > 0:
            probs = probs / (probs.sum() + 1e-15)  # 防止除以零
        else:
            # 如果所有值为零，则使用均匀分布
            probs = torch.ones_like(probs) / probs.numel()
        action_dist = torch.distributions.Categorical(probs)
        action = action_dist.sample()
        return action.item()         #策略网络输出

    # 计算目标Q值,直接用策略网络的输出概率进行期望计算  HV/MV1/MV2
    def calc_target_switch(self, rewards, next_states):
        if (next_states.size()[1] == HV_state.size()[0]):  # 后者只有一维
            next_probs = self.actor_HV(next_states)
            next_log_probs = torch.log(next_probs + 1e-8)
            entropy = -torch.sum(next_probs * next_log_probs, dim=1, keepdim=True)
            q1_value = self.target_critic_1_HV(next_states)
            q2_value = self.target_critic_2_HV(next_states)
            min_qvalue = torch.sum(next_probs * torch.min(q1_value, q2_value), dim=1, keepdim=True)
            next_value = min_qvalue + self.log_alpha_HV.exp() * entropy
            td_target = rewards + self.gamma * next_value
        if (next_states.size()[1] == MV1_state.size()[0]):
            next_probs = self.actor_MV1(next_states)
            next_log_probs = torch.log(next_probs + 1e-8)
            entropy = -torch.sum(next_probs * next_log_probs, dim=1, keepdim=True)
            q1_value = self.target_critic_1_MV1(next_states)
            q2_value = self.target_critic_2_MV1(next_states)
            min_qvalue = torch.sum(next_probs * torch.min(q1_value, q2_value), dim=1, keepdim=True)
            next_value = min_qvalue + self.log_alpha_MV1.exp() * entropy
            td_target = rewards + self.gamma * next_value
        if (next_states.size()[1] == MV2_state.size()[0]):
            next_probs = self.actor_MV2(next_states)
            next_log_probs = torch.log(next_probs + 1e-8)
            entropy = -torch.sum(next_probs * next_log_probs, dim=1, keepdim=True)
            q1_value = self.target_critic_1_MV2(next_states)
            q2_value = self.target_critic_2_MV2(next_states)
            min_qvalue = torch.sum(next_probs * torch.min(q1_value, q2_value), dim=1, keepdim=True)
            next_value = min_qvalue + self.log_alpha_MV2.exp() * entropy
            td_target = rewards + self.gamma * next_value
        return td_target

    # 计算目标Q值,直接用策略网络的输出概率进行期望计算  HV/MV1/MV2
    def calc_target_OLTC(self, rewards, next_states):
        if (next_states.size()[1] == OLTCL_state.size()[0]):  # 后者只有一维
            next_probs = self.actor_OLTCL(next_states)
            next_log_probs = torch.log(next_probs + 1e-8)
            entropy = -torch.sum(next_probs * next_log_probs, dim=1, keepdim=True)
            q1_value = self.target_critic_1_OLTCL(next_states)
            q2_value = self.target_critic_2_OLTCL(next_states)
            min_qvalue = torch.sum(next_probs * torch.min(q1_value, q2_value), dim=1, keepdim=True)
            next_value = min_qvalue + self.log_alpha_OLTCL.exp() * entropy
            td_target = rewards + self.gamma * next_value
        if (next_states.size()[1] == OLTCR_state.size()[0]):
            next_probs = self.actor_OLTCR(next_states)
            next_log_probs = torch.log(next_probs + 1e-8)
            entropy = -torch.sum(next_probs * next_log_probs, dim=1, keepdim=True)
            q1_value = self.target_critic_1_OLTCR(next_states)
            q2_value = self.target_critic_2_OLTCR(next_states)
            min_qvalue = torch.sum(next_probs * torch.min(q1_value, q2_value), dim=1, keepdim=True)
            next_value = min_qvalue + self.log_alpha_OLTCR.exp() * entropy
            td_target = rewards + self.gamma * next_value
        return td_target

    def soft_update(self, net, target_net):
        for param_target, param in zip(target_net.parameters(),net.parameters()):
            param_target.data.copy_(param_target.data * (1.0 - self.tau) + param.data * self.tau)

    def store_transition(self, state_HV, action_HV, reward_HV, next_state_HV, state_MV1, action_MV1, reward_MV1, next_state_MV1,
                         state_MV2, action_MV2, reward_MV2, next_state_MV2,state_OLTCL, action_OLTCL, reward_OLTCL, next_state_OLTCL,
                         state_OLTCR, action_OLTCR, reward_OLTCR, next_state_OLTCR):
        transition = np.hstack((state_HV, [action_HV],[reward_HV], next_state_HV,state_MV1, [action_MV1], [reward_MV1], next_state_MV1,
                                state_MV2, [action_MV2], [reward_MV2], next_state_MV2, state_OLTCL, [action_OLTCL],[reward_OLTCL], next_state_OLTCL,
                                state_OLTCR, [action_OLTCR], [reward_OLTCR], next_state_OLTCR))#
        index = self.memory_counter % self.MEMORY_CAPACITY
        self.memory[index, :] = transition
        self.memory_counter += 1

    def learn(self):
        sample_index = np.random.choice(self.MEMORY_CAPACITY, batch_size)
        batch_memory = self.memory[sample_index, :]

        batch_state_HV = torch.FloatTensor(batch_memory[:, :self.state_dim_HV]).to(device)
        batch_action_HV = torch.LongTensor(batch_memory[:, self.state_dim_HV:self.state_dim_HV + 1].astype(int)).to(device)
        batch_reward_HV = torch.FloatTensor(batch_memory[:, self.state_dim_HV + 1:self.state_dim_HV + 2]).to(device)
        batch_next_state_HV = torch.FloatTensor(batch_memory[:, self.state_dim_HV + 2: 2 * self.state_dim_HV + 2]).to(device)
        batch_size1 = 2 * self.state_dim_HV + 2  # HV

        batch_state_MV1 = torch.FloatTensor(batch_memory[:, batch_size1: batch_size1 + self.state_dim_MV1]).to(device)
        batch_action_MV1 = torch.FloatTensor(batch_memory[:,batch_size1 + self.state_dim_MV1: batch_size1 + self.state_dim_MV1 + 1].astype(int)).to(device)
        batch_reward_MV1 = torch.FloatTensor(batch_memory[:,batch_size1 + self.state_dim_MV1 + 1: batch_size1 + self.state_dim_MV1 + 2]).to(device)
        batch_next_state_MV1 = torch.FloatTensor(batch_memory[:,batch_size1 + self.state_dim_MV1 + 2: batch_size1 + 2 * self.state_dim_MV1 + 2]).to(device)
        batch_size2 = batch_size1 + 2 * self.state_dim_MV1 + 2  # HV+MV1
        batch_state_MV2 = torch.FloatTensor(batch_memory[:, batch_size2: batch_size2 + self.state_dim_MV2]).to(device)
        batch_action_MV2 = torch.FloatTensor(batch_memory[:,batch_size2 + self.state_dim_MV2: batch_size2 + self.state_dim_MV2 + 1].astype(int)).to(device)
        batch_reward_MV2 = torch.FloatTensor(batch_memory[:, batch_size2 + self.state_dim_MV2 + 1: batch_size2 + self.state_dim_MV2 + 2]).to(device)
        batch_next_state_MV2 = torch.FloatTensor(batch_memory[:, batch_size2 + self.state_dim_MV2 + 2: batch_size2 + 2 * self.state_dim_MV2 + 2]).to(device)
        batch_size3 = batch_size2 + 2 * self.state_dim_MV2 + 2  # HV+MV1+MV2
        batch_state_OLTCL = torch.FloatTensor(batch_memory[:, batch_size3: batch_size3 + self.state_dim_OLTCL]).to(device)
        batch_action_OLTCL = torch.FloatTensor(batch_memory[:,batch_size3 + self.state_dim_OLTCL: batch_size3 + self.state_dim_OLTCL + 1].astype(int)).to(device)
        batch_reward_OLTCL = torch.FloatTensor(batch_memory[:, batch_size3 + self.state_dim_OLTCL + 1: batch_size3 + self.state_dim_OLTCL + 2]).to(device)
        batch_next_state_OLTCL = torch.FloatTensor(batch_memory[:, batch_size3 + self.state_dim_OLTCL + 2: batch_size3 + 2 * self.state_dim_OLTCL + 2]).to(device)
        batch_size4 = batch_size3 + 2 * self.state_dim_OLTCL + 2  # HV+MV1+MV2+OLTCL
        batch_state_OLTCR = torch.FloatTensor(batch_memory[:, batch_size4: batch_size4 + self.state_dim_OLTCR]).to(device)
        batch_action_OLTCR = torch.FloatTensor(batch_memory[:,batch_size4 + self.state_dim_OLTCR: batch_size4 + self.state_dim_OLTCR + 1].astype(int)).to(device)
        batch_reward_OLTCR = torch.FloatTensor(batch_memory[:, batch_size4 + self.state_dim_OLTCR + 1: batch_size4 + self.state_dim_OLTCR + 2]).to(device)
        batch_next_state_OLTCR = torch.FloatTensor(batch_memory[:, batch_size4 + self.state_dim_OLTCR + 2: batch_size4 + 2 * self.state_dim_OLTCR + 2]).to(device)
        # print(batch_size4 + 2 * self.state_dim_OLTCR + 2) 6326

        ##################### Agent-HV #####################
        # 更新两个Q网络
        td_target_HV = self.calc_target_switch(batch_reward_HV, batch_next_state_HV)
        batch_action_HV =  batch_action_HV.to(torch.int64)
        critic_1_q_values_HV = self.critic_1_HV(batch_state_HV).gather(1, batch_action_HV)
        critic_1_loss_HV = torch.mean(F.mse_loss(critic_1_q_values_HV, td_target_HV.detach()))
        critic_2_q_values_HV = self.critic_2_HV(batch_state_HV).gather(1, batch_action_HV)
        critic_2_loss_HV = torch.mean(F.mse_loss(critic_2_q_values_HV, td_target_HV.detach()))
        self.critic_1_optimizer_HV.zero_grad()
        critic_1_loss_HV.backward()
        self.critic_1_optimizer_HV.step()
        self.critic_2_optimizer_HV.zero_grad()
        critic_2_loss_HV.backward()
        self.critic_2_optimizer_HV.step()
        # 更新策略网络  actor
        probs_HV = self.actor_HV(batch_state_HV)
        log_probs_HV = torch.log(probs_HV + 1e-8)
        # 直接根据概率计算熵
        entropy_HV = -torch.sum(probs_HV * log_probs_HV, dim=1, keepdim=True)  #
        q1_value_HV = self.critic_1_HV(batch_state_HV)
        q2_value_HV = self.critic_2_HV(batch_state_HV)
        min_qvalue_HV = torch.sum(probs_HV * torch.min(q1_value_HV, q2_value_HV),dim=1,keepdim=True)  # 直接根据概率计算期望
        actor_loss_HV = torch.mean(-self.log_alpha_HV.exp() * entropy_HV - min_qvalue_HV)
        self.actor_optimizer_HV.zero_grad()
        actor_loss_HV.backward()
        self.actor_optimizer_HV.step()
        # 更新alpha值
        alpha_loss_HV = torch.mean((entropy_HV - self.target_entropy).detach() * self.log_alpha_HV.exp())
        self.log_alpha_optimizer_HV.zero_grad()
        alpha_loss_HV.backward()
        self.log_alpha_optimizer_HV.step()
        self.soft_update(self.critic_1_HV, self.target_critic_1_HV)
        self.soft_update(self.critic_2_HV, self.target_critic_2_HV)

        ##################### Agent-MV1 #####################
        # 更新两个Q网络
        td_target_MV1 = self.calc_target_switch(batch_reward_MV1, batch_next_state_MV1)
        batch_action_MV1 = batch_action_MV1.to(torch.int64)
        critic_1_q_values_MV1 = self.critic_1_MV1(batch_state_MV1).gather(1, batch_action_MV1)
        critic_1_loss_MV1 = torch.mean(F.mse_loss(critic_1_q_values_MV1, td_target_MV1.detach()))
        critic_2_q_values_MV1 = self.critic_2_MV1(batch_state_MV1).gather(1, batch_action_MV1)
        critic_2_loss_MV1 = torch.mean(F.mse_loss(critic_2_q_values_MV1, td_target_MV1.detach()))
        self.critic_1_optimizer_MV1.zero_grad()
        critic_1_loss_MV1.backward()
        self.critic_1_optimizer_MV1.step()
        self.critic_2_optimizer_MV1.zero_grad()
        critic_2_loss_MV1.backward()
        self.critic_2_optimizer_MV1.step()
        # 更新策略网络  actor
        probs_MV1 = self.actor_MV1(batch_state_MV1)
        log_probs_MV1 = torch.log(probs_MV1 + 1e-8)
        # 直接根据概率计算熵
        entropy_MV1 = -torch.sum(probs_MV1 * log_probs_MV1, dim=1, keepdim=True)  #
        q1_value_MV1 = self.critic_1_MV1(batch_state_MV1)
        q2_value_MV1 = self.critic_2_MV1(batch_state_MV1)
        min_qvalue_MV1 = torch.sum(probs_MV1 * torch.min(q1_value_MV1, q2_value_MV1), dim=1, keepdim=True)  # 直接根据概率计算期望
        actor_loss_MV1 = torch.mean(-self.log_alpha_MV1.exp() * entropy_MV1 - min_qvalue_MV1)
        self.actor_optimizer_MV1.zero_grad()
        actor_loss_MV1.backward()
        self.actor_optimizer_MV1.step()
        # 更新alpha值
        alpha_loss_MV1 = torch.mean((entropy_MV1 - self.target_entropy).detach() * self.log_alpha_MV1.exp())
        self.log_alpha_optimizer_MV1.zero_grad()
        alpha_loss_MV1.backward()
        self.log_alpha_optimizer_MV1.step()
        self.soft_update(self.critic_1_MV1, self.target_critic_1_MV1)
        self.soft_update(self.critic_2_MV1, self.target_critic_2_MV1)

        ##################### Agent-MV2 #####################
        # 更新两个Q网络
        td_target_MV2 = self.calc_target_switch(batch_reward_MV2, batch_next_state_MV2)
        batch_action_MV2 = batch_action_MV2.to(torch.int64)
        critic_1_q_values_MV2 = self.critic_1_MV2(batch_state_MV2).gather(1, batch_action_MV2)
        critic_1_loss_MV2 = torch.mean(F.mse_loss(critic_1_q_values_MV2, td_target_MV2.detach()))
        critic_2_q_values_MV2 = self.critic_2_MV2(batch_state_MV2).gather(1, batch_action_MV2)
        critic_2_loss_MV2 = torch.mean(F.mse_loss(critic_2_q_values_MV2, td_target_MV2.detach()))
        self.critic_1_optimizer_MV2.zero_grad()
        critic_1_loss_MV2.backward()
        self.critic_1_optimizer_MV2.step()
        self.critic_2_optimizer_MV2.zero_grad()
        critic_2_loss_MV2.backward()
        self.critic_2_optimizer_MV2.step()
        # 更新策略网络  actor
        probs_MV2 = self.actor_MV2(batch_state_MV2)
        log_probs_MV2 = torch.log(probs_MV2 + 1e-8)
        # 直接根据概率计算熵
        entropy_MV2 = -torch.sum(probs_MV2 * log_probs_MV2, dim=1, keepdim=True)  #
        q1_value_MV2 = self.critic_1_MV2(batch_state_MV2)
        q2_value_MV2 = self.critic_2_MV2(batch_state_MV2)
        min_qvalue_MV2 = torch.sum(probs_MV2 * torch.min(q1_value_MV2, q2_value_MV2), dim=1, keepdim=True)  # 直接根据概率计算期望
        actor_loss_MV2 = torch.mean(-self.log_alpha_MV2.exp() * entropy_MV2 - min_qvalue_MV2)
        self.actor_optimizer_MV2.zero_grad()
        actor_loss_MV2.backward()
        self.actor_optimizer_MV2.step()
        # 更新alpha值
        alpha_loss_MV2 = torch.mean((entropy_MV2 - self.target_entropy).detach() * self.log_alpha_MV2.exp())
        self.log_alpha_optimizer_MV2.zero_grad()
        alpha_loss_MV2.backward()
        self.log_alpha_optimizer_MV2.step()
        self.soft_update(self.critic_1_MV2, self.target_critic_1_MV2)
        self.soft_update(self.critic_2_MV2, self.target_critic_2_MV2)

        ##################### Agent-OLTCL #####################
        # 更新两个Q网络
        td_target_OLTCL = self.calc_target_OLTC(batch_reward_OLTCL, batch_next_state_OLTCL)
        batch_action_OLTCL = batch_action_OLTCL.to(torch.int64)
        critic_1_q_values_OLTCL = self.critic_1_OLTCL(batch_state_OLTCL).gather(1, batch_action_OLTCL)
        critic_1_loss_OLTCL = torch.mean(F.mse_loss(critic_1_q_values_OLTCL, td_target_OLTCL.detach()))
        critic_2_q_values_OLTCL = self.critic_2_OLTCL(batch_state_OLTCL).gather(1, batch_action_OLTCL)
        critic_2_loss_OLTCL = torch.mean(F.mse_loss(critic_2_q_values_OLTCL, td_target_OLTCL.detach()))
        self.critic_1_optimizer_OLTCL.zero_grad()
        critic_1_loss_OLTCL.backward()
        self.critic_1_optimizer_OLTCL.step()
        self.critic_2_optimizer_OLTCL.zero_grad()
        critic_2_loss_OLTCL.backward()
        self.critic_2_optimizer_OLTCL.step()
        # 更新策略网络  actor
        probs_OLTCL = self.actor_OLTCL(batch_state_OLTCL)
        log_probs_OLTCL = torch.log(probs_OLTCL + 1e-8)
        # 直接根据概率计算熵
        entropy_OLTCL = -torch.sum(probs_OLTCL * log_probs_OLTCL, dim=1, keepdim=True)  #
        q1_value_OLTCL = self.critic_1_OLTCL(batch_state_OLTCL)
        q2_value_OLTCL = self.critic_2_OLTCL(batch_state_OLTCL)
        min_qvalue_OLTCL = torch.sum(probs_OLTCL * torch.min(q1_value_OLTCL, q2_value_OLTCL), dim=1, keepdim=True)  # 直接根据概率计算期望
        actor_loss_OLTCL = torch.mean(-self.log_alpha_OLTCL.exp() * entropy_OLTCL - min_qvalue_OLTCL)
        self.actor_optimizer_OLTCL.zero_grad()
        actor_loss_OLTCL.backward()
        self.actor_optimizer_OLTCL.step()
        # 更新alpha值
        alpha_loss_OLTCL = torch.mean((entropy_OLTCL - self.target_entropy).detach() * self.log_alpha_OLTCL.exp())
        self.log_alpha_optimizer_OLTCL.zero_grad()
        alpha_loss_OLTCL.backward()
        self.log_alpha_optimizer_OLTCL.step()
        self.soft_update(self.critic_1_OLTCL, self.target_critic_1_OLTCL)
        self.soft_update(self.critic_2_OLTCL, self.target_critic_2_OLTCL)

        ##################### Agent-OLTCR #####################
        # 更新两个Q网络
        td_target_OLTCR = self.calc_target_OLTC(batch_reward_OLTCR, batch_next_state_OLTCR)
        batch_action_OLTCR = batch_action_OLTCR.to(torch.int64)
        critic_1_q_values_OLTCR = self.critic_1_OLTCR(batch_state_OLTCR).gather(1, batch_action_OLTCR)
        critic_1_loss_OLTCR = torch.mean(F.mse_loss(critic_1_q_values_OLTCR, td_target_OLTCR.detach()))
        critic_2_q_values_OLTCR = self.critic_2_OLTCR(batch_state_OLTCR).gather(1, batch_action_OLTCR)
        critic_2_loss_OLTCR = torch.mean(F.mse_loss(critic_2_q_values_OLTCR, td_target_OLTCR.detach()))
        self.critic_1_optimizer_OLTCR.zero_grad()
        critic_1_loss_OLTCR.backward()
        self.critic_1_optimizer_OLTCR.step()
        self.critic_2_optimizer_OLTCR.zero_grad()
        critic_2_loss_OLTCR.backward()
        self.critic_2_optimizer_OLTCR.step()
        # 更新策略网络  actor
        probs_OLTCR = self.actor_OLTCR(batch_state_OLTCR)
        log_probs_OLTCR = torch.log(probs_OLTCR + 1e-8)
        # 直接根据概率计算熵
        entropy_OLTCR = -torch.sum(probs_OLTCR * log_probs_OLTCR, dim=1, keepdim=True)  #
        q1_value_OLTCR = self.critic_1_OLTCR(batch_state_OLTCR)
        q2_value_OLTCR = self.critic_2_OLTCR(batch_state_OLTCR)
        min_qvalue_OLTCR = torch.sum(probs_OLTCR * torch.min(q1_value_OLTCR, q2_value_OLTCR), dim=1,keepdim=True)  # 直接根据概率计算期望
        actor_loss_OLTCR = torch.mean(-self.log_alpha_OLTCR.exp() * entropy_OLTCR - min_qvalue_OLTCR)
        self.actor_optimizer_OLTCR.zero_grad()
        actor_loss_OLTCR.backward()
        self.actor_optimizer_OLTCR.step()
        # 更新alpha值
        alpha_loss_OLTCR = torch.mean((entropy_OLTCR - self.target_entropy).detach() * self.log_alpha_OLTCR.exp())
        self.log_alpha_optimizer_OLTCR.zero_grad()
        alpha_loss_OLTCR.backward()
        self.log_alpha_optimizer_OLTCR.step()
        self.soft_update(self.critic_1_OLTCR, self.target_critic_1_OLTCR)
        self.soft_update(self.critic_2_OLTCR, self.target_critic_2_OLTCR)

    def save(self):
        torch.save(self.actor_HV.state_dict(), self.directory_HV + 'evalHV.pth')
        torch.save(self.actor_MV1.state_dict(), self.directory_MV1 + 'evalMV1.pth')
        torch.save(self.actor_MV2.state_dict(), self.directory_MV2 + 'evalMV2.pth')
        torch.save(self.actor_OLTCL.state_dict(), self.directory_OLTCL + 'evalOLTCL.pth')
        torch.save(self.actor_OLTCR.state_dict(), self.directory_OLTCR + 'evalOLTCR.pth')

    def load(self):
        self.actor_HV.load_state_dict(torch.load(self.directory_HV + 'evalHV.pth'))
        self.actor_MV1.load_state_dict(torch.load(self.directory_MV1 + 'evalMV1.pth'))
        self.actor_MV2.load_state_dict(torch.load(self.directory_MV2 + 'evalMV2.pth'))
        self.actor_OLTCL.load_state_dict(torch.load(self.directory_OLTCL + 'evalOLTCL.pth'))
        self.actor_OLTCR.load_state_dict(torch.load(self.directory_OLTCR + 'evalOLTCR.pth'))

def reset(t, bus_data, edge_data, control_edge, pv_data, curve, HV_action_list, MV_bus_data, MV_edge_data,MV_control_edge, MV_pv_data,
          MV_action_list, tap1, tap2, tap3, tap4, tap5, root_fixv):
    # 第7 12指当前拓扑支路
    HV_voltage,HV_Pload,HV_Qload,HV_PPV,HV_tp,MV_voltage,MV_Pload,MV_Qload,MV_PPV,MV_tp,_= \
        RE.MISOCP(t, bus_data, edge_data, control_edge, pv_data, curve, HV_action_list, MV_bus_data, MV_edge_data,MV_control_edge, MV_pv_data,
                  MV_action_list, tap1, tap2, tap3, tap4, tap5, root_fixv)
    min_val = 0.9
    max_val = 1.1
    HV_voltage= torch.from_numpy(HV_voltage).float()
    HV_Pload = torch.from_numpy(HV_Pload).float()
    HV_Qload = torch.from_numpy(HV_Qload).float()
    HV_PPV = torch.from_numpy(HV_PPV).float()
    HV_tp = torch.from_numpy(HV_tp).float()
    HV_voltage = (HV_voltage - min_val) / (max_val - min_val)

    MV_voltage = torch.from_numpy(MV_voltage).float()
    MV_Pload = torch.from_numpy(MV_Pload).float()
    MV_Qload = torch.from_numpy(MV_Qload).float()
    MV_PPV = torch.from_numpy(MV_PPV).float()
    MV_tp = torch.from_numpy(MV_tp).float()
    MV_voltage = (MV_voltage - min_val) / (max_val - min_val)

    MV1_voltage = MV_voltage[0, 0:100].unsqueeze(0)
    MV1_Pload = 10*MV_Pload[0, 0:100].unsqueeze(0)
    MV1_Qload = 10*MV_Qload[0, 0:100].unsqueeze(0)
    MV1_PPV = 10*MV_PPV[0, 0:100].unsqueeze(0)
    MV1_tp = MV_tp[0,0:105].unsqueeze(0)

    MV2_voltage = MV_voltage[0, 100:230].unsqueeze(0)
    MV2_Pload = 10*MV_Pload[0, 100:230].unsqueeze(0)
    MV2_Qload = 10*MV_Qload[0, 100:230].unsqueeze(0)
    MV2_PPV = 10*MV_PPV[0, 100:230].unsqueeze(0)
    MV2_tp = MV_tp[0, 105:239].unsqueeze(0)

    OLTCL_voltage= torch.cat((HV_voltage,MV1_voltage), dim=1)
    OLTCL_Pload = torch.cat((HV_Pload, MV1_Pload), dim=1)
    OLTCL_Qload = torch.cat((HV_Qload, MV1_Qload), dim=1)
    OLTCL_PPV = torch.cat((HV_PPV, MV1_PPV), dim=1)
    OLTCL_tp = torch.cat((HV_tp, MV1_tp), dim=1)

    OLTCR_voltage = torch.cat((HV_voltage, MV2_voltage), dim=1)
    OLTCR_Pload = torch.cat((HV_Pload, MV2_Pload), dim=1)
    OLTCR_Qload = torch.cat((HV_Qload, MV2_Qload), dim=1)
    OLTCR_PPV = torch.cat((HV_PPV, MV2_PPV), dim=1)
    OLTCR_tp = torch.cat((HV_tp, MV2_tp), dim=1)

    HV_state = torch.cat((HV_voltage,HV_Pload,HV_Qload,HV_PPV,HV_tp),dim=1) # torch.Size([1, 280])
    MV1_state = torch.cat((MV1_voltage,MV1_Pload,MV1_Qload,MV1_PPV,MV1_tp),dim=1)  # torch.Size([1, 505])
    MV2_state = torch.cat((MV2_voltage,MV2_Pload,MV2_Qload,MV2_PPV,MV2_tp), dim=1)  # torch.Size([1, 654])
    OLTCL_state = torch.cat((OLTCL_voltage,OLTCL_Pload,OLTCL_Qload,OLTCL_PPV,OLTCL_tp), dim=1)  # torch.Size([1, 654])
    OLTCR_state = torch.cat((OLTCR_voltage,OLTCR_Pload,OLTCR_Qload,OLTCR_PPV,OLTCR_tp), dim=1)  # torch.Size([1, 934])
    # print(HV_state.size(),MV1_state.size(),MV2_state.size(),OLTCL_state.size(),OLTCR_state.size())
    return HV_state,MV1_state,MV2_state,OLTCL_state,OLTCR_state

def step(t, bus_data, edge_data, control_edge, pv_data, curve, HV_action_list, MV_bus_data, MV_edge_data,MV_control_edge, MV_pv_data,
          MV_action_list, tap1, tap2, tap3, tap4, tap5, root_fixv):
    # 第7 12指当前拓扑支路
    HV_voltage,HV_Pload,HV_Qload,HV_PPV,HV_tp,MV_voltage,MV_Pload,MV_Qload,MV_PPV,MV_tp,reward= \
        RE.MISOCP(t, bus_data, edge_data, control_edge, pv_data, curve, HV_action_list, MV_bus_data, MV_edge_data,MV_control_edge, MV_pv_data,
                  MV_action_list, tap1, tap2, tap3, tap4, tap5, root_fixv)
    min_val = 0.9
    max_val = 1.1
    HV_voltage= torch.from_numpy(HV_voltage).float()
    HV_Pload = torch.from_numpy(HV_Pload).float()
    HV_Qload = torch.from_numpy(HV_Qload).float()
    HV_PPV = torch.from_numpy(HV_PPV).float()
    HV_tp = torch.from_numpy(HV_tp).float()
    HV_voltage = (HV_voltage - min_val) / (max_val - min_val)

    MV_voltage = torch.from_numpy(MV_voltage).float()
    MV_Pload = torch.from_numpy(MV_Pload).float()
    MV_Qload = torch.from_numpy(MV_Qload).float()
    MV_PPV = torch.from_numpy(MV_PPV).float()
    MV_tp = torch.from_numpy(MV_tp).float()
    MV_voltage = (MV_voltage - min_val) / (max_val - min_val)

    MV1_voltage = MV_voltage[0, 0:100].unsqueeze(0)
    MV1_Pload = 10*MV_Pload[0, 0:100].unsqueeze(0)
    MV1_Qload = 10*MV_Qload[0, 0:100].unsqueeze(0)
    MV1_PPV = 10*MV_PPV[0, 0:100].unsqueeze(0)
    MV1_tp = MV_tp[0,0:105].unsqueeze(0)

    MV2_voltage = MV_voltage[0, 100:230].unsqueeze(0)
    MV2_Pload = 10*MV_Pload[0, 100:230].unsqueeze(0)
    MV2_Qload = 10*MV_Qload[0, 100:230].unsqueeze(0)
    MV2_PPV = 10*MV_PPV[0, 100:230].unsqueeze(0)
    MV2_tp = MV_tp[0, 105:239].unsqueeze(0)

    OLTCL_voltage= torch.cat((HV_voltage,MV1_voltage), dim=1)
    OLTCL_Pload = torch.cat((HV_Pload, MV1_Pload), dim=1)
    OLTCL_Qload = torch.cat((HV_Qload, MV1_Qload), dim=1)
    OLTCL_PPV = torch.cat((HV_PPV, MV1_PPV), dim=1)
    OLTCL_tp = torch.cat((HV_tp, MV1_tp), dim=1)

    OLTCR_voltage = torch.cat((HV_voltage, MV2_voltage), dim=1)
    OLTCR_Pload = torch.cat((HV_Pload, MV2_Pload), dim=1)
    OLTCR_Qload = torch.cat((HV_Qload, MV2_Qload), dim=1)
    OLTCR_PPV = torch.cat((HV_PPV, MV2_PPV), dim=1)
    OLTCR_tp = torch.cat((HV_tp, MV2_tp), dim=1)

    HV_state = torch.cat((HV_voltage,HV_Pload,HV_Qload,HV_PPV,HV_tp),dim=1) # torch.Size([1, 280])
    MV1_state = torch.cat((MV1_voltage,MV1_Pload,MV1_Qload,MV1_PPV,MV1_tp),dim=1)  # torch.Size([1, 505])
    MV2_state = torch.cat((MV2_voltage,MV2_Pload,MV2_Qload,MV2_PPV,MV2_tp), dim=1)  # torch.Size([1, 654])
    OLTCL_state = torch.cat((OLTCL_voltage,OLTCL_Pload,OLTCL_Qload,OLTCL_PPV,OLTCL_tp), dim=1)  # torch.Size([1, 654])
    OLTCR_state = torch.cat((OLTCR_voltage,OLTCR_Pload,OLTCR_Qload,OLTCR_PPV,OLTCR_tp), dim=1)  # torch.Size([1, 934])
    # print(HV_state.size(),MV1_state.size(),MV2_state.size(),OLTCL_state.size(),OLTCR_state.size())
    return HV_state,MV1_state,MV2_state,OLTCL_state,OLTCR_state,-10*reward

def generate_switch_pairs(N):
    switch_pairs = []
    # (0, 0) 表示不做改动，加入到列表中
    switch_pairs.append((0, 0))
    # 生成所有可能的开关对 (s, j)，但排除 (s, s) 的情况
    for s, j in itertools.product(range(1, N + 1), repeat=2):
        if s != j:  # 排除 (s, s) 的情况
            switch_pairs.append((s, j))
    return switch_pairs


if __name__ == '__main__':
    path = 'parameter_big.xlsx'
    ##################################### 参数的获得 ###########################################
    ##################################### HV参数 ###########################################
    # print(pv_curve,load_curve,pv_curve[0],load_curve[0]) # 获得具体曲线!!!!!!!!
    bus_data = pd.read_excel(path, sheet_name='HV_node')  # 索引从0开始
    edge_data = pd.read_excel(path, sheet_name='HV_line')
    control_edge = pd.read_excel(path, sheet_name='HV_contrable_branch')
    pv_data = pd.read_excel(path, sheet_name='hv_pv_position')  # PV接入节点、容量
    curve = pd.read_excel(path, sheet_name='load_curve')  # PV曲线
    origin_edge = pd.read_excel(path, sheet_name='hv_original')

    edge_list = []
    r = {}
    x = {}
    for i in range(len(edge_data)):  # 边的数量
        temp = edge_data.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        r_pu = temp.iloc[3]
        x_pu = temp.iloc[4]
        # I_max=temp.iloc[5]                    #支路最大电流
        edge_list.append((start_bus, end_bus))  # 把支路提取出来
        r[(start_bus, end_bus)] = r_pu  # 整理每条支路的电阻
        x[(start_bus, end_bus)] = x_pu  # 整理每条支路的电抗
        # Imax[(start_bus,end_bus)]=I_max          #整理每条支路的电流最大值
    edge_set = set(edge_list)

    origin_list = []
    for i in range(len(origin_edge)):
        temp = origin_edge.iloc[i]
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        origin_list.append((start_bus, end_bus))

    control_list = []
    for i in range(len(control_edge)):  # 边的数量
        temp = control_edge.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        control_list.append((start_bus, end_bus))  # 把支路提取出来

    control_set = set(control_list)
    fixed_list = list(edge_set - control_set)  # 34

    p_load = {}
    q_load = {}
    for i in range(len(bus_data)):
        temp_load = bus_data.iloc[i]  # 第i行
        bus = i + 4
        p_load[bus] = temp_load.iloc[1]  # 从第0列开始
        q_load[bus] = temp_load.iloc[2]  # 从第0列开始

    pv_list = []
    pv = {}
    all_bus_list = list(range(4, 60))
    for i in range(len(pv_data)):
        temp = pv_data.iloc[i]  # 获取表格中第i行数据
        pv_bus_index = int(temp.iloc[0])  # 光伏安装节点编号
        pv_list.append(pv_bus_index)
        pv_capacity = temp.iloc[1]
        pv[pv_bus_index] = pv_capacity
    no_pv_bus = list(set(all_bus_list) - set(pv_list))
    pv_curve = curve.iloc[:, 2]
    load_curve = curve.iloc[:, 1]
    # print(len(edge_list),len(r),len(control_list),len(fixed_list),len(p_load),len(origin_edge),len(pv_list),len(no_pv_bus)) # 56 56 13 43 56 50 6 50

    ##################################### MV总参数 ###########################################
    MV_bus_data = pd.read_excel(path, sheet_name='MV_node')  # 索引从0开始
    MV_edge_data = pd.read_excel(path, sheet_name='MV_line')
    MV_control_edge = pd.read_excel(path, sheet_name='MV_contrable_branch')
    MV_pv_data = pd.read_excel(path, sheet_name='mv_pv_position')  # PV接入节点、容量
    MV_origin_edge = pd.read_excel(path, sheet_name='mv_original')

    MV_edge_list = []
    MV_r = {}
    MV_x = {}
    for i in range(len(MV_edge_data)):  # 边的数量
        temp = MV_edge_data.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        MV_r_pu = temp.iloc[3]
        MV_x_pu = temp.iloc[4]
        # I_max=temp.iloc[5]                    #支路最大电流
        MV_edge_list.append((start_bus, end_bus))  # 把支路提取出来
        MV_r[(start_bus, end_bus)] = MV_r_pu  # 整理每条支路的电阻
        MV_x[(start_bus, end_bus)] = MV_x_pu  # 整理每条支路的电抗
        # Imax[(start_bus,end_bus)]=I_max          #整理每条支路的电流最大值
    MV_edge_set = set(MV_edge_list)

    MV_origin_list = []
    for i in range(len(MV_origin_edge)):
        temp = MV_origin_edge.iloc[i]
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        MV_origin_list.append((start_bus, end_bus))

    MV_control_list = []
    for i in range(len(MV_control_edge)):  # 边的数量
        temp = MV_control_edge.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        MV_control_list.append((start_bus, end_bus))  # 把支路提取出来

    MV_control_set = set(MV_control_list)
    MV_fixed_list = list(MV_edge_set - MV_control_set)

    MV_p_load = {}
    MV_q_load = {}
    for i in range(len(MV_bus_data)):
        temp_load = MV_bus_data.iloc[i]  # 第i行
        bus = i + 60
        MV_p_load[bus] = temp_load.iloc[1]  # 从第0列开始
        MV_q_load[bus] = temp_load.iloc[2]  # 从第0列开始

    MV_pv_list = []
    MV_pv = {}
    MV_all_bus_list = list(range(60, 290))
    for i in range(len(MV_pv_data)):
        temp = MV_pv_data.iloc[i]  # 获取表格中第i行数据
        pv_bus_index = int(temp.iloc[0])  # 光伏安装节点编号
        MV_pv_list.append(pv_bus_index)
        pv_capacity = temp.iloc[1]
        MV_pv[pv_bus_index] = pv_capacity
    MV_no_pv_bus = list(set(MV_all_bus_list) - set(MV_pv_list))
    # print(len(MV_edge_list),len(MV_r),len(MV_control_list),len(MV_fixed_list),len(MV_p_load),len(MV_origin_edge),len(MV_pv_list),len(MV_no_pv_bus)) # 239 239 31 208 230 225 25 205

    ##################################### MV1总参数 ###########################################
    MV1_bus_data = pd.read_excel(path, sheet_name='MV1_node')  # 索引从0开始
    MV1_edge_data = pd.read_excel(path, sheet_name='MV1_line')
    MV1_control_edge = pd.read_excel(path, sheet_name='MV1_contrable_branch')
    MV1_edge_list = []
    MV1_r = {}
    MV1_x = {}
    for i in range(len(MV1_edge_data)):  # 边的数量
        temp = MV1_edge_data.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        MV1_r_pu = temp.iloc[3]
        MV1_x_pu = temp.iloc[4]
        # I_max=temp.iloc[5]                    #支路最大电流
        MV1_edge_list.append((start_bus, end_bus))  # 把支路提取出来
        MV1_r[(start_bus, end_bus)] = MV1_r_pu  # 整理每条支路的电阻
        MV1_x[(start_bus, end_bus)] = MV1_x_pu  # 整理每条支路的电抗
        # Imax[(start_bus,end_bus)]=I_max          #整理每条支路的电流最大值
    MV1_edge_set = set(MV1_edge_list)

    MV1_origin_list = MV_origin_list[127:225]

    MV1_control_list = []
    for i in range(len(MV1_control_edge)):  # 边的数量
        temp = MV1_control_edge.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        MV1_control_list.append((start_bus, end_bus))  # 把支路提取出来

    MV1_control_set = set(MV1_control_list)
    MV1_fixed_list = list(MV1_edge_set - MV1_control_set)

    MV1_p_load = {}
    MV1_q_load = {}
    for i in range(len(MV1_bus_data)):
        temp_load = MV1_bus_data.iloc[i]  # 第i行
        bus = i + 60
        MV1_p_load[bus] = temp_load.iloc[1]  # 从第0列开始
        MV1_q_load[bus] = temp_load.iloc[2]  # 从第0列开始
    # print(len(MV1_edge_list),len(MV1_control_list),len(MV1_p_load),len(MV1_fixed_list)) #105 15 100 90

    ##################################### MV2总参数 ###########################################
    MV2_bus_data = pd.read_excel(path, sheet_name='MV2_node')  # 索引从0开始
    MV2_edge_data = pd.read_excel(path, sheet_name='MV2_line')
    MV2_control_edge = pd.read_excel(path, sheet_name='MV2_contrable_branch')

    MV2_edge_list = []
    MV2_r = {}
    MV2_x = {}
    for i in range(len(MV2_edge_data)):  # 边的数量
        temp = MV2_edge_data.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        MV2_r_pu = temp.iloc[3]
        MV2_x_pu = temp.iloc[4]
        # I_max=temp.iloc[5]                    #支路最大电流
        MV2_edge_list.append((start_bus, end_bus))  # 把支路提取出来
        MV2_r[(start_bus, end_bus)] = MV2_r_pu  # 整理每条支路的电阻
        MV2_x[(start_bus, end_bus)] = MV2_x_pu  # 整理每条支路的电抗
        # Imax[(start_bus,end_bus)]=I_max          #整理每条支路的电流最大值
    MV2_edge_set = set(MV2_edge_list)

    MV2_origin_list = MV_origin_list[0:127]

    MV2_control_list = []
    for i in range(len(MV2_control_edge)):  # 边的数量
        temp = MV2_control_edge.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        MV2_control_list.append((start_bus, end_bus))  # 把支路提取出来

    MV2_control_set = set(MV2_control_list)
    MV2_fixed_list = list(MV2_edge_set - MV2_control_set)

    MV2_p_load = {}
    MV2_q_load = {}
    for i in range(len(MV2_bus_data)):
        temp_load = MV2_bus_data.iloc[i]  # 第i行
        bus = i + 60
        MV2_p_load[bus] = temp_load.iloc[1]  # 从第0列开始
        MV2_q_load[bus] = temp_load.iloc[2]  # 从第0列开始
    # print(len(MV2_edge_list), len(MV2_control_list), len(MV2_p_load), len(MV2_fixed_list))  # 134 16 130 118

    ##################################### 智能体 ###########################################
    actor_lr = 0.0001
    critic_lr = 0.0003
    alpha_lr = 0.0003
    state_dim_HV = len(bus_data)*4+len(edge_data)  # Ui Pload Qload PPV onehot-branch
    action_dim_HV = len(control_edge)**2-len(control_edge)+1
    state_dim_MV1 = len(MV1_bus_data) * 4 + len(MV1_edge_data)  # Ui Pload Qload PPV onehot-branch
    action_dim_MV1 = len(MV1_control_edge) ** 2 - len(MV1_control_edge) + 1
    state_dim_MV2 = len(MV2_bus_data) * 4 + len(MV2_edge_data)  # Ui Pload Qload PPV onehot-branch
    action_dim_MV2 = len(MV2_control_edge) ** 2 - len(MV2_control_edge) + 1
    OLTC_dw =5
    state_dim_OLTCL = state_dim_HV+state_dim_MV1 #
    action_dim_OLTCL = OLTC_dw**2
    state_dim_OLTCR = state_dim_HV+state_dim_MV2 #
    action_dim_OLTCR = OLTC_dw**3
    hidden_dim = 512
    gamma = 0.99
    tau = 0.005  # 软更新参数
    batch_size = 64
    target_entropy = -1
    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    MEMORY_CAPACITY = 10000  # 10000

    HV_N = len(control_list)
    HV_switch_pairs = generate_switch_pairs(HV_N)  # 生成所有可能的开关对 (s, j) s j指excel里的第s j个支路
    MV1_N = len(MV1_control_list)
    MV1_switch_pairs = generate_switch_pairs(MV1_N)  # 生成所有可能的开关对 (s, j) s j指excel里的第s j个支路
    MV2_N = len(MV2_control_list)
    MV2_switch_pairs = generate_switch_pairs(MV2_N)  # 生成所有可能的开关对 (s, j) s j指excel里的第s j个支路
    # print(len(MV1_switch_pairs),len(MV2_switch_pairs),MV1_switch_pairs)
    HV_feeder=[4,5,6,7,8,9]
    MV1_feeder=[60,105]
    MV2_feeder = [160,193,232]

    true_agent = SAC(hidden_dim, state_dim_HV, action_dim_HV, state_dim_MV1, action_dim_MV1,state_dim_MV2, action_dim_MV2,
                     state_dim_OLTCL, action_dim_OLTCL,state_dim_OLTCR, action_dim_OLTCR,actor_lr, critic_lr, alpha_lr,
                     target_entropy, tau,gamma,MEMORY_CAPACITY, 'HV','MV1','MV2','OLTCL','OLTC2', device)

    mode = 'train'

    if mode == 'train':
        epochs = 5000
        episodes = 23
        root_fix_hv = 1.03
        reward_multi = np.zeros((1, epochs))

        for h in range(epochs):
            # ————————————————————————————————————————————————————————初始化状态——————————————————————————————————————————————#
            begin = 0   # 开始时间点
            rr = 0

            tap1 = 1; tap2 = 1; tap3 = 1; tap4 = 1; tap5 = 1
            HV_current_list= copy.deepcopy(origin_list)  # 初始HV重构方案
            MV_current_list= copy.deepcopy(MV_origin_list)  # 初始MV重构方案
            MV1_current_list = copy.deepcopy(MV1_origin_list)  # 初始MV1重构方案
            MV2_current_list = copy.deepcopy(MV2_origin_list)  # 初始MV2重构方案
            HV_action_list = copy.deepcopy(origin_list)  # HV重构方案
            MV_action_list = copy.deepcopy(MV_origin_list)  # MV重构方案
            MV1_action_list = copy.deepcopy(MV1_origin_list)  # MV1重构方案
            MV2_action_list = copy.deepcopy(MV2_origin_list)  # MV2重构方案

            HV_state,MV1_state,MV2_state,OLTCL_state,OLTCR_state = \
            reset(begin, bus_data, edge_data, control_edge, pv_data, curve, HV_current_list, MV_bus_data,
                  MV_edge_data,MV_control_edge,MV_pv_data, MV_current_list, tap1, tap2, tap3, tap4, tap5, root_fix_hv)
            # 280 505 654 785 934
            # print(HV_state.size()[1],MV1_state.size()[1],MV2_state.size()[1],OLTCL_state.size()[1],OLTCR_state.size()[1])

            for tt in range(episodes):
                flag = 1
                opcost=0
                HV_action_switch = true_agent.take_action_switch(HV_state,HV_current_list,HV_switch_pairs,control_list,HV_feeder)
                MV1_action_switch = true_agent.take_action_switch(MV1_state, MV1_current_list, MV1_switch_pairs, MV1_control_list,MV1_feeder)
                MV2_action_switch = true_agent.take_action_switch(MV2_state, MV2_current_list, MV2_switch_pairs,MV2_control_list, MV2_feeder)
                OLTCL_action = true_agent.take_action_OLTC(OLTCL_state)
                OLTCR_action = true_agent.take_action_OLTC(OLTCR_state)
                tap1 = OLTCL_action//OLTC_dw  # 0-4
                tap2 = OLTCL_action%OLTC_dw
                tap3 = OLTCR_action//(OLTC_dw**2)
                tap4 = OLTCR_action%(OLTC_dw**2)//OLTC_dw
                tap5 = OLTCR_action%OLTC_dw
                # print(h, tt,HV_action_switch,MV1_action_switch,MV2_action_switch,tap1,tap2,tap3,tap4,tap5)

                if(HV_action_switch==0):
                    HV_current_list = HV_action_list
                elif ((control_list[HV_switch_pairs[HV_action_switch][0] - 1] in HV_current_list) and
                      (control_list[HV_switch_pairs[HV_action_switch][1] - 1] not in HV_current_list)):
                    HV_action_list.remove(control_list[HV_switch_pairs[HV_action_switch][0] - 1])
                    HV_action_list.append(control_list[HV_switch_pairs[HV_action_switch][1] - 1])
                    HV_current_list = HV_action_list
                    opcost = opcost-0.1 # 动作成本
                else:  # 选择了不合法的动作
                    flag = 0

                if (MV1_action_switch == 0):
                    MV1_current_list = MV1_action_list
                elif ((MV1_control_list[MV1_switch_pairs[MV1_action_switch][0] - 1] in MV1_current_list) and
                      (MV1_control_list[MV1_switch_pairs[MV1_action_switch][1] - 1] not in MV1_current_list)):
                    MV1_action_list.remove(MV1_control_list[MV1_switch_pairs[MV1_action_switch][0] - 1])
                    MV1_action_list.append(MV1_control_list[MV1_switch_pairs[MV1_action_switch][1] - 1])
                    MV1_current_list = MV1_action_list
                    opcost = opcost - 0.1  # 动作成本
                else:  # 选择了不合法的动作
                    flag = 0

                if (MV2_action_switch == 0):
                    MV2_current_list = MV2_action_list
                elif ((MV2_control_list[MV2_switch_pairs[MV2_action_switch][0] - 1] in MV2_current_list) and
                      (MV2_control_list[MV2_switch_pairs[MV2_action_switch][1] - 1] not in MV2_current_list)):
                    MV2_action_list.remove(MV2_control_list[MV2_switch_pairs[MV2_action_switch][0] - 1])
                    MV2_action_list.append(MV2_control_list[MV2_switch_pairs[MV2_action_switch][1] - 1])
                    MV2_current_list = MV2_action_list
                    opcost = opcost - 0.1  # 动作成本
                else:  # 选择了不合法的动作
                    flag = 0

                MV_action_list = MV1_action_list + MV2_action_list  #
                MV_current_list = MV_action_list
                # print(flag)

                if(flag==1):
                    HV_state_, MV1_state_, MV2_state_, OLTCL_state_, OLTCR_state_ ,reward = \
                        step(begin + tt, bus_data, edge_data, control_edge, pv_data, curve, HV_action_list, MV_bus_data,
                              MV_edge_data, MV_control_edge, MV_pv_data, MV_action_list, tap1, tap2, tap3, tap4, tap5,root_fix_hv)
                else:  # 选择了不合法的动作
                    flag = 1
                    HV_state_, MV1_state_, MV2_state_, OLTCL_state_, OLTCR_state_, reward = \
                        step(begin + tt, bus_data, edge_data, control_edge, pv_data, curve, HV_action_list, MV_bus_data,
                             MV_edge_data, MV_control_edge, MV_pv_data, MV_action_list, tap1, tap2, tap3, tap4, tap5,root_fix_hv)
                    reward=-100

                if (reward == -100) or (reward == -10):
                    if (reward == -100): print('*' * 30)

                reward = reward + opcost
                opcost=0
                print(h, tt,HV_action_switch,MV1_action_switch,MV2_action_switch,tap1,tap2,tap3,tap4,tap5,reward)
                HV_state = HV_state.squeeze()
                HV_state_ = HV_state_.squeeze()  #
                MV1_state = MV1_state.squeeze()
                MV1_state_ = MV1_state_.squeeze()  #
                MV2_state = MV2_state.squeeze()
                MV2_state_ = MV2_state_.squeeze()  #
                OLTCL_state = OLTCL_state.squeeze()
                OLTCL_state_ = OLTCL_state_.squeeze()
                OLTCR_state = OLTCR_state.squeeze()
                OLTCR_state_ = OLTCR_state_.squeeze()
                true_agent.store_transition(HV_state, HV_action_switch, reward, HV_state_,MV1_state, MV1_action_switch, reward, MV1_state_,
                                            MV2_state, MV2_action_switch, reward, MV2_state_,OLTCL_state, OLTCL_action, reward, OLTCL_state_,
                                            OLTCR_state, OLTCR_action, reward, OLTCR_state_)
                rr = rr + reward

                if true_agent.memory_counter >= 2:
                    true_agent.learn()
                true_agent.save()

                HV_state, MV1_state, MV2_state, OLTCL_state, OLTCR_state = \
                reset(begin +tt +1, bus_data, edge_data, control_edge, pv_data, curve, HV_current_list, MV_bus_data,
                      MV_edge_data, MV_control_edge, MV_pv_data, MV_current_list, tap1, tap2, tap3, tap4, tap5,root_fix_hv)

            reward_multi[0, h] = rr
            # name = 'MA_multi_v.mat'
            # sio.savemat(name, {'MA_r_multi': reward_multi})



    if mode == 'test':
        true_agent.load()
        episodes = 23
        begin = 0
        root_fix_hv = 1.03
        min_val = 0.9
        max_val = 1.1
        rr=0
        tap1 = 1;tap2 = 1;tap3 = 1;tap4 = 1;tap5 = 1
        reward_test = np.zeros((1, episodes))
        OLTC = np.zeros((5, 23))
        voltage289 = np.zeros((1, 289))

        HV_current_list = copy.deepcopy(origin_list)  # 初始HV重构方案
        MV_current_list = copy.deepcopy(MV_origin_list)  # 初始MV重构方案
        MV1_current_list = copy.deepcopy(MV1_origin_list)  # 初始MV1重构方案
        MV2_current_list = copy.deepcopy(MV2_origin_list)  # 初始MV2重构方案
        HV_action_list = copy.deepcopy(origin_list)  # HV重构方案
        MV_action_list = copy.deepcopy(MV_origin_list)  # MV重构方案
        MV1_action_list = copy.deepcopy(MV1_origin_list)  # MV1重构方案
        MV2_action_list = copy.deepcopy(MV2_origin_list)  # MV2重构方案

        HV_state, MV1_state, MV2_state, OLTCL_state, OLTCR_state = \
            reset(begin, bus_data, edge_data, control_edge, pv_data, curve, HV_current_list, MV_bus_data,
                  MV_edge_data, MV_control_edge, MV_pv_data, MV_current_list, tap1, tap2, tap3, tap4, tap5, root_fix_hv)

        for tt in range(episodes):
            flag = 1
            opcost = 0
            ######################### Agent HV  ############################
            HV_state= HV_state.to(device)
            true_agent.actor_HV = true_agent.actor_HV.to(device)  # 将 actor 移到指定设备
            HV_switch_mask = SPM.switch_pairs_Mask_main(HV_current_list, HV_switch_pairs, control_list,HV_feeder)
            HV_switch_mask = torch.tensor(HV_switch_mask, dtype=torch.float32).to(device)  # 将 switch_mask 移到同一设备
            HV_action_value = true_agent.actor_HV.forward(HV_state)  # 将 vv 输入到 actor，并确保在相同设备
            HV_masked_probs = true_agent.apply_mask(HV_action_value, HV_switch_mask)
            HV_action_switch = torch.argmax(HV_masked_probs)

            ######################### Agent MV1  ############################
            MV1_state = MV1_state.to(device)
            true_agent.actor_MV1 = true_agent.actor_MV1.to(device)  # 将 actor 移到指定设备
            MV1_switch_mask = SPM.switch_pairs_Mask_main(MV1_current_list, MV1_switch_pairs, MV1_control_list, MV1_feeder)
            MV1_switch_mask = torch.tensor(MV1_switch_mask, dtype=torch.float32).to(device)  # 将 switch_mask 移到同一设备
            MV1_action_value = true_agent.actor_MV1.forward(MV1_state)  # 将 vv 输入到 actor，并确保在相同设备
            MV1_masked_probs = true_agent.apply_mask(MV1_action_value, MV1_switch_mask)
            MV1_action_switch = torch.argmax(MV1_masked_probs)

            ######################### Agent MV2  ############################
            MV2_state = MV2_state.to(device)
            true_agent.actor_MV2 = true_agent.actor_MV2.to(device)  # 将 actor 移到指定设备
            MV2_switch_mask = SPM.switch_pairs_Mask_main(MV2_current_list, MV2_switch_pairs, MV2_control_list,MV2_feeder)
            MV2_switch_mask = torch.tensor(MV2_switch_mask, dtype=torch.float32).to(device)  # 将 switch_mask 移到同一设备
            MV2_action_value = true_agent.actor_MV2.forward(MV2_state)  # 将 vv 输入到 actor，并确保在相同设备
            MV2_masked_probs = true_agent.apply_mask(MV2_action_value, MV2_switch_mask)
            MV2_action_switch = torch.argmax(MV2_masked_probs)

            ######################### Agent OLTCL  ############################
            OLTCL_state = OLTCL_state.to(device)
            true_agent.actor_OLTCL = true_agent.actor_OLTCL.to(device)  # 将 actor 移到指定设备
            OLTCL_action_value = true_agent.actor_OLTCL.forward(OLTCL_state)  # 将 vv 输入到 actor，并确保在相同设备
            OLTCL_action = torch.argmax(OLTCL_action_value)

            ######################### Agent OLTCR  ############################
            OLTCR_state = OLTCR_state.to(device)
            true_agent.actor_OLTCR = true_agent.actor_OLTCR.to(device)  # 将 actor 移到指定设备
            OLTCR_action_value = true_agent.actor_OLTCR.forward(OLTCR_state)  # 将 vv 输入到 actor，并确保在相同设备
            OLTCR_action = torch.argmax(OLTCR_action_value)

            tap1 = torch.div(OLTCL_action, OLTC_dw, rounding_mode='trunc')
            tap2 = OLTCL_action % OLTC_dw
            tap3 = torch.div(OLTCR_action, OLTC_dw ** 2, rounding_mode='trunc')  # 保持当前行为
            tap4 = torch.div(OLTCR_action % (OLTC_dw ** 2), OLTC_dw, rounding_mode='trunc')  # 保持当前行为
            tap5 = OLTCR_action % OLTC_dw

            if (HV_action_switch == 0):
                HV_current_list = HV_action_list
            elif ((control_list[HV_switch_pairs[HV_action_switch][0] - 1] in HV_current_list) and
                  (control_list[HV_switch_pairs[HV_action_switch][1] - 1] not in HV_current_list)):
                HV_action_list.remove(control_list[HV_switch_pairs[HV_action_switch][0] - 1])
                HV_action_list.append(control_list[HV_switch_pairs[HV_action_switch][1] - 1])
                HV_current_list = HV_action_list
                opcost = opcost - 0.1  # 动作成本
            else:  # 选择了不合法的动作
                flag = 0

            if (MV1_action_switch == 0):
                MV1_current_list = MV1_action_list
            elif ((MV1_control_list[MV1_switch_pairs[MV1_action_switch][0] - 1] in MV1_current_list) and
                  (MV1_control_list[MV1_switch_pairs[MV1_action_switch][1] - 1] not in MV1_current_list)):
                MV1_action_list.remove(MV1_control_list[MV1_switch_pairs[MV1_action_switch][0] - 1])
                MV1_action_list.append(MV1_control_list[MV1_switch_pairs[MV1_action_switch][1] - 1])
                MV1_current_list = MV1_action_list
                opcost = opcost - 0.1  # 动作成本
            else:  # 选择了不合法的动作
                flag = 0

            if (MV2_action_switch == 0):
                MV2_current_list = MV2_action_list
            elif ((MV2_control_list[MV2_switch_pairs[MV2_action_switch][0] - 1] in MV2_current_list) and
                  (MV2_control_list[MV2_switch_pairs[MV2_action_switch][1] - 1] not in MV2_current_list)):
                MV2_action_list.remove(MV2_control_list[MV2_switch_pairs[MV2_action_switch][0] - 1])
                MV2_action_list.append(MV2_control_list[MV2_switch_pairs[MV2_action_switch][1] - 1])
                MV2_current_list = MV2_action_list
                opcost = opcost - 0.1  # 动作成本
            else:  # 选择了不合法的动作
                flag = 0

            MV_action_list = MV1_action_list + MV2_action_list  #
            MV_current_list = MV_action_list

            if (flag == 1):
                HV_state_, MV1_state_, MV2_state_, OLTCL_state_, OLTCR_state_, reward = \
                    step(begin + tt, bus_data, edge_data, control_edge, pv_data, curve, HV_action_list, MV_bus_data,
                         MV_edge_data, MV_control_edge, MV_pv_data, MV_action_list, tap1, tap2, tap3, tap4, tap5,
                         root_fix_hv)
            else:  # 选择了不合法的动作
                flag = 1
                HV_state_, MV1_state_, MV2_state_, OLTCL_state_, OLTCR_state_, reward = \
                    step(begin + tt, bus_data, edge_data, control_edge, pv_data, curve, HV_action_list, MV_bus_data,
                         MV_edge_data, MV_control_edge, MV_pv_data, MV_action_list, tap1, tap2, tap3, tap4, tap5,
                         root_fix_hv)
                reward = -100

            if (reward == -100) or (reward == -10):
                if (reward == -100): print('*' * 30)

            reward = reward + opcost
            opcost = 0
            rr = rr+reward
            print(tt, HV_action_switch.item(), MV1_action_switch.item(), MV2_action_switch.item(), tap1.item(),
                  tap2.item(), tap3.item(), tap4.item(), tap5.item(), reward)

            vol1to3= torch.tensor([1.05,1.05,1.05]) # 节点1-3设为1.05
            vol_HV = HV_state_[0, :56] * (max_val - min_val) + min_val
            vol_MV1 = MV1_state_[0, :100] * (max_val - min_val) + min_val
            vol_MV2 = MV2_state_[0, :130] * (max_val - min_val) + min_val
            vtotal= torch.cat((vol1to3,vol_HV, vol_MV1, vol_MV2), dim=0)
            voltage289 = np.vstack((voltage289, vtotal))  # 289-3

            HV_state = HV_state.squeeze()
            HV_state_ = HV_state_.squeeze()  #
            MV1_state = MV1_state.squeeze()
            MV1_state_ = MV1_state_.squeeze()  #
            MV2_state = MV2_state.squeeze()
            MV2_state_ = MV2_state_.squeeze()  #
            OLTCL_state = OLTCL_state.squeeze()
            OLTCL_state_ = OLTCL_state_.squeeze()
            OLTCR_state = OLTCR_state.squeeze()
            OLTCR_state_ = OLTCR_state_.squeeze()

            HV_state, MV1_state, MV2_state, OLTCL_state, OLTCR_state = \
                reset(begin + tt + 1, bus_data, edge_data, control_edge, pv_data, curve, HV_current_list, MV_bus_data,
                      MV_edge_data, MV_control_edge, MV_pv_data, MV_current_list, tap1, tap2, tap3, tap4, tap5,root_fix_hv)

            reward_test[0, tt] = reward
            OLTC[0, tt] = tap1
            OLTC[1, tt] = tap2
            OLTC[2, tt] = tap3
            OLTC[3, tt] = tap4
            OLTC[4, tt] = tap5

        name = 'MA_multi_test.mat'
        # print(voltage289,OLTC)
        savemat = sio.savemat(name,{'REWARD_epoch_plus_testC': reward_test, 'VOLTAGE_TEST': voltage289, 'OLTC_action': OLTC})
        print(rr)