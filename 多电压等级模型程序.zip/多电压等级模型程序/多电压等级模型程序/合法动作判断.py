import networkx as nx
import pandas as pd
import gurobipy as grb
import time
import numpy as np

# 检查辐射约束：判断是否存在任何一个支路跨越两个不同的馈线
def check_radiation_constraint(feeder_list, edge_list):
    graph = nx.Graph()
    graph.add_edges_from(edge_list)

    # 遍历所有节点，检查是否有节点同时属于多个馈线
    node_feeder_mapping = {}

    for feeder in feeder_list:
        for start, end in edge_list:
            if start == feeder or end == feeder:
                if start not in node_feeder_mapping:
                    node_feeder_mapping[start] = []
                if end not in node_feeder_mapping:
                    node_feeder_mapping[end] = []
                node_feeder_mapping[start].append(feeder)
                node_feeder_mapping[end].append(feeder)

    # 如果任何一个节点被分配到多个馈线，则违反辐射约束
    for node, feeders in node_feeder_mapping.items():
        if len(set(feeders)) > 1:
            return False

    # 检查是否存在环路（环网检测）
    cycles = list(nx.simple_cycles(graph))  # 查找图中的所有环路
    if cycles:
        return False
    return True


# 检查根节点之间的连通性
def check_root_nodes_connectivity(feeder_list, edge_list, root_nodes):
    # 为每个馈线建立一个子图，确保每个根节点在自己的馈线内
    for feeder in feeder_list:
        feeder_nodes = set()
        for start, end in edge_list:
            if start == feeder:
                feeder_nodes.add(start)
                feeder_nodes.add(end)
            elif end == feeder:
                feeder_nodes.add(start)
                feeder_nodes.add(end)

        subgraph = nx.Graph()
        subgraph.add_edges_from(
            [(start, end) for start, end in edge_list if start in feeder_nodes and end in feeder_nodes])

        # 检查子图是否为空
        if len(subgraph.nodes) > 0:
            if not nx.is_connected(subgraph):
                return False
        else:
            continue  # 跳过孤岛馈线的检查

    # 检查是否根节点之间通过其他馈线间接连通
    graph = nx.Graph()
    graph.add_edges_from(edge_list)

    for i in range(len(root_nodes)):
        for j in range(i + 1, len(root_nodes)):
            if root_nodes[i] not in graph.nodes or root_nodes[j] not in graph.nodes:
                continue  # 如果根节点不在图中，跳过该次检查
            if nx.has_path(graph, root_nodes[i], root_nodes[j]):
                return False
    return True


# 检查是否存在孤岛
def check_island_formation(feeder_list, edge_list, root_nodes):
    graph = nx.Graph()
    graph.add_edges_from(edge_list)

    # 遍历所有节点，检查是否有节点无法从根节点连通
    visited = set()

    def dfs(node, visited_nodes):
        if node not in graph:
            return  # 如果节点不在图中，直接返回
        visited_nodes.add(node)
        for neighbor in graph.neighbors(node):
            if neighbor not in visited_nodes:
                dfs(neighbor, visited_nodes)

    # 从所有根节点出发，进行深度优先遍历
    visited_nodes = set()
    for root in root_nodes:
        if root not in visited:
            dfs(root, visited_nodes)
            visited.update(visited_nodes)

    # 检查是否有非根节点无法到达
    isolated_nodes = set(graph.nodes) - visited
    isolated_nodes -= set(root_nodes)  # 不考虑根节点作为孤岛
    if isolated_nodes:
        return False
    return True


# 总体检查函数
def check_network_conditions(feeder_list, edge_list, root_nodes):
    if not check_radiation_constraint(feeder_list, edge_list):
        return 0
    if not check_root_nodes_connectivity(feeder_list, edge_list, root_nodes):
        return 0
    if not check_island_formation(feeder_list, edge_list, root_nodes):
        return 0
    # print("KKK网络满足所有约束条件！")
    return 1


for i in range(0,3):
    # 测试用例
    feeder_list = [1, 2, 11, 20]
    edge_list = [(1, 3), (3, 4), (4, 5), (6, 7), (2, 6), (7, 8), (4, 9), (1, 10), (11, 12), (12, 13), (13, 14)]
    root_nodes = [1, 2, 11, 20]

    flag=check_network_conditions(feeder_list, edge_list, root_nodes)
    print(flag)




