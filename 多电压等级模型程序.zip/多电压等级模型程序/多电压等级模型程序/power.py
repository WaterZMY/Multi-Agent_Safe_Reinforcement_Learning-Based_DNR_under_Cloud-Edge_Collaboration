import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from torch_geometric.nn import GCNConv
import scipy.io as sio
import os
import pandas as pd
import numpy as np
#获取每个慢时间尺度的功率

def reset_power(t,active_load,reactive_load):
    # path = r'.\附表1有功无功分离.xlsx'
    # active_load = pd.read_excel(path, sheet_name='active')
    # reactive_load = pd.read_excel(path, sheet_name='reactive')
    p_load = np.zeros((12,33))
    q_load = np.zeros((12,33))
    for h in range(12):  # 快时间的平均
        for n in range(33):  # 节点
            temp_active = active_load.iloc[n]  # 第i行
            temp_reactive = reactive_load.iloc[n]  # 第i行
            p_load[h, n] = temp_active.iloc[t+h]  # 从第0列开始
            q_load[h, n] = temp_reactive.iloc[t+h]
    averageP1 = np.mean(p_load, axis=0)  # 计算每一列的均值，即压缩行
    averageQ1 = np.mean(q_load, axis=0)
    averageP1 = torch.from_numpy(averageP1).float()
    averageQ1 = torch.from_numpy(averageQ1).float()

    return 100*averageP1,100*averageQ1