# 如果需要部分支路可重构，把一些支路的状态固定即可
import pandas as pd
import gurobipy as grb
import time
import numpy as np



def MISOCP(t,bus_data,edge_data,control_edge, pv_data,curve,action_list,MV_bus_data,MV_edge_data,MV_control_edge, MV_pv_data,
           MV_action_list,tap1,tap2,tap3,tap4,tap5,root_fixv):
    ##################################### 参数的获得 ###########################################
    ##################################### HV参数 ###########################################
    theta = 0.4  #PV 可能太大了
    pv_curve = curve.iloc[:, 2]
    load_curve = curve.iloc[:, 1]
    load_curve_time = load_curve[t]
    pv_curve_time = theta * pv_curve[t]

    edge_list = []
    r = {}
    x = {}
    for i in range(len(edge_data)):  # 边的数量
        temp = edge_data.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        r_pu = temp.iloc[3]
        x_pu = temp.iloc[4]
        # I_max=temp.iloc[5]                    #支路最大电流
        edge_list.append((start_bus, end_bus))  # 把支路提取出来
        r[(start_bus, end_bus)] = r_pu  # 整理每条支路的电阻
        x[(start_bus, end_bus)] = x_pu  # 整理每条支路的电抗
        # Imax[(start_bus,end_bus)]=I_max          #整理每条支路的电流最大值
    edge_set = set(edge_list)

    # action_list = []
    # for i in range(len(action_edge)):
    #     temp = action_edge.iloc[i]
    #     start_bus = int(temp.iloc[0])
    #     end_bus = int(temp.iloc[1])
    #     action_list.append((start_bus, end_bus))

    control_list = []
    for i in range(len(control_edge)):  # 边的数量
        temp = control_edge.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        control_list.append((start_bus, end_bus))  # 把支路提取出来

    control_set = set(control_list)
    fixed_list = list(edge_set - control_set)  # 34

    p_load0 = {}
    q_load0 = {}
    for i in range(len(bus_data)):
        temp_load = bus_data.iloc[i]  # 第i行
        bus = i + 4
        p_load0[bus] = temp_load.iloc[1]  # 从第0列开始
        q_load0[bus] = temp_load.iloc[2]  # 从第0列开始

    pv_list = []
    pv = {}
    all_bus_list = list(range(4, 60))
    for i in range(len(pv_data)):
        temp = pv_data.iloc[i]  # 获取表格中第i行数据
        pv_bus_index = int(temp.iloc[0])  # 光伏安装节点编号
        pv_list.append(pv_bus_index)
        pv_capacity = temp.iloc[1]
        pv[pv_bus_index] = pv_capacity
    no_pv_bus = list(set(all_bus_list) - set(pv_list))

    ##################################### HV参数 ###########################################
    MV_edge_list = []
    MV_r = {}
    MV_x = {}
    for i in range(len(MV_edge_data)):  # 边的数量
        temp = MV_edge_data.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        MV_r_pu = temp.iloc[3]
        MV_x_pu = temp.iloc[4]
        # I_max=temp.iloc[5]                    #支路最大电流
        MV_edge_list.append((start_bus, end_bus))  # 把支路提取出来
        MV_r[(start_bus, end_bus)] = MV_r_pu  # 整理每条支路的电阻
        MV_x[(start_bus, end_bus)] = MV_x_pu  # 整理每条支路的电抗
        # Imax[(start_bus,end_bus)]=I_max          #整理每条支路的电流最大值
    MV_edge_set = set(MV_edge_list)

    # MV_action_list = []
    # for i in range(len(MV_action_edge)):
    #     temp = MV_action_edge.iloc[i]
    #     start_bus = int(temp.iloc[0])
    #     end_bus = int(temp.iloc[1])
    #     MV_action_list.append((start_bus, end_bus))

    MV_control_list = []
    for i in range(len(MV_control_edge)):  # 边的数量
        temp = MV_control_edge.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        MV_control_list.append((start_bus, end_bus))  # 把支路提取出来

    MV_control_set = set(MV_control_list)
    MV_fixed_list = list(MV_edge_set - MV_control_set)

    MV_p_load0 = {}
    MV_q_load0 = {}
    for i in range(len(MV_bus_data)):
        temp_load = MV_bus_data.iloc[i]  # 第i行
        bus = i + 60
        MV_p_load0[bus] = temp_load.iloc[1]  # 从第0列开始
        MV_q_load0[bus] = temp_load.iloc[2]  # 从第0列开始

    MV_pv_list = []
    MV_pv = {}
    MV_all_bus_list = list(range(60, 290))
    for i in range(len(MV_pv_data)):
        temp = MV_pv_data.iloc[i]  # 获取表格中第i行数据
        pv_bus_index = int(temp.iloc[0])  # 光伏安装节点编号
        MV_pv_list.append(pv_bus_index)
        pv_capacity = temp.iloc[1]
        MV_pv[pv_bus_index] = pv_capacity
    MV_no_pv_bus = list(set(MV_all_bus_list) - set(MV_pv_list))

    p_load = {k: v * load_curve_time for k, v in p_load0.items()}
    q_load = {k: v * load_curve_time for k, v in q_load0.items()}
    MV_p_load = {k: v * load_curve_time for k, v in MV_p_load0.items()}
    MV_q_load = {k: v * load_curve_time for k, v in MV_q_load0.items()}

    ###################################################################################################
    m = grb.Model()
    edge_list = grb.tuplelist(edge_list)  # 56
    control_list = grb.tuplelist(control_list)  # 13
    fixed_list = grb.tuplelist(edge_set - control_set)  # 43
    MV_edge_list = grb.tuplelist(MV_edge_list)  # 239
    MV_control_list = grb.tuplelist(MV_control_list)  # 31
    MV_fixed_list = grb.tuplelist(MV_edge_set - MV_control_set)  # 206

    X = m.addVars(edge_list, vtype=grb.GRB.BINARY, name='X')
    y = m.addVars(edge_list, name='y')
    m.addConstrs(X[i, j] == 1 for i, j in action_list)

    v_list = [i for i in range(4, 60)]  # 编号4-59
    v = m.addVars(v_list, name='v')  # 电压的平方，从1开始索引
    p = m.addVars(edge_list, lb=-1000, ub=grb.GRB.INFINITY, name='p')  # 支路有功潮流
    q = m.addVars(edge_list, lb=-1000, ub=grb.GRB.INFINITY, name='q')  # 支路无功潮流
    l = m.addVars(edge_list, name='l')  # 电流的平方

    p4 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p4')  # 上级主网购入有功
    q4 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q4')  # 上级主网购入无功
    p5 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p5')  # 上级主网购入有功
    q5 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q5')  # 上级主网购入无功
    p6 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p6')  # 上级主网购入有功
    q6 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q6')  # 上级主网购入无功
    p7 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p7')  # 上级主网购入有功
    q7 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q7')  # 上级主网购入无功
    p8 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p8')  # 上级主网购入有功
    q8 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q8')  # 上级主网购入无功
    p9 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p9')  # 上级主网购入有功
    q9 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q9')  # 上级主网购入无功

    # 在对m进行再次操作前，需要进行update
    m.update()

    m.addConstr(grb.quicksum(X[i, j] for i, j in edge_list) == 50)  # 支路状态变量约束nb-ns,nb为总节点数，ns为根节点数,56-6=50

    m.addConstr(p4 == p.sum(4, '*') + p_load[4])
    m.addConstr(q4 == q.sum(4, '*') + q_load[4])
    m.addConstr(p5 == p.sum(5, '*') + p_load[5])
    m.addConstr(q5 == q.sum(5, '*') + q_load[5])
    m.addConstr(p6 == p.sum(6, '*') + p_load[6])
    m.addConstr(q6 == q.sum(6, '*') + q_load[6])
    m.addConstr(p7 == p.sum(7, '*') + p_load[7])
    m.addConstr(q7 == q.sum(7, '*') + q_load[7])
    m.addConstr(p8 == p.sum(8, '*') + p_load[8])
    m.addConstr(q8 == q.sum(8, '*') + q_load[8])
    m.addConstr(p9 == p.sum(9, '*') + p_load[9])
    m.addConstr(q9 == q.sum(9, '*') + q_load[9])

    pv_re = m.addVars(v_list, name='pv_re')  # 光伏无功出力
    pv_ac = m.addVars(v_list, name='pv_re')  # 光伏有功出力
    for k in range(4, 60):
        if (k in pv_list):
            m.addConstr(pv_ac[k] >= 0.95 * pv[k] * pv_curve_time)
            m.addConstr(pv_ac[k] <= pv[k] * pv_curve_time)
            # m.addConstr((pv_re[k] <= 0.3 * pv_ac[k]))
            # m.addConstr((pv_re[k] >= -0.3 * pv_ac[k]))
            m.addConstr((pv_re[k] ** 2 + (pv_ac[k]) ** 2 <= (theta * pv[k]) ** 2))
        else:
            m.addConstr(pv_ac[k] == 0)
            m.addConstr(pv_re[k] == 0)

    m.addConstrs(p.sum(k, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + p_load[k] -pv_ac[k] == 0 for k in range(10, 18))  #
    m.addConstrs(q.sum(k, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + q_load[k] -pv_re[k] == 0 for k in range(10, 18))  #
    m.addConstrs(p.sum(k, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + p_load[k] -pv_ac[k] == 0 for k in range(19, 30))  #
    m.addConstrs(q.sum(k, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + q_load[k] -pv_re[k] == 0 for k in range(19, 30))
    m.addConstrs(p.sum(k, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + p_load[k] -pv_ac[k] == 0 for k in range(31, 41))  #
    m.addConstrs(q.sum(k, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + q_load[k] -pv_re[k] == 0 for k in range(31, 41))
    m.addConstrs(p.sum(k, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + p_load[k] -pv_ac[k] == 0 for k in range(42, 46))  #
    m.addConstrs(q.sum(k, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + q_load[k] -pv_re[k] == 0 for k in range(42, 46))  #
    m.addConstrs(p.sum(k, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + p_load[k] -pv_ac[k] == 0 for k in range(47, 56))  #
    m.addConstrs(q.sum(k, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + q_load[k] -pv_re[k] == 0 for k in range(47, 56))
    m.addConstrs(p.sum(k, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + p_load[k] -pv_ac[k] == 0 for k in range(57, 60))  #
    m.addConstrs(q.sum(k, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + q_load[k] -pv_re[k] == 0 for k in range(57, 60))

    # 大M法约束
    M = 1e4
    m.addConstrs(X[i, j] * M >= p[i, j] for i, j in edge_list)
    m.addConstrs(p[i, j] >= -X[i, j] * M for i, j in edge_list)
    m.addConstrs(X[i, j] * M >= q[i, j] for i, j in edge_list)
    m.addConstrs(q[i, j] >= -X[i, j] * M for i, j in edge_list)

    m.addConstrs(y[i, j] == (1 - X[i, j]) * M for i, j in edge_list)
    m.addConstrs(v[i] - v[j] <= y[i, j] + 2 * (r[i, j] * p[i, j] + x[i, j] * q[i, j]) - (r[i, j] ** 2 + x[i, j] ** 2) * l[i, j]for i, j in edge_list)
    m.addConstrs(v[i] - v[j] >= -y[i, j] + 2 * (r[i, j] * p[i, j] + x[i, j] * q[i, j]) - (r[i, j] ** 2 + x[i, j] ** 2) * l[i, j]for i, j in edge_list)
    #
    m.addConstrs(l[i, j] * v[i] >= (p[i, j] ** 2 + q[i, j] ** 2) for i, j in edge_list)
    # m.addConstrs(l[i,j]<=5*Imax[i,j] * X[i,j] for i,j in edge_list)

    m.addConstr(v[4] == root_fixv**2)
    m.addConstr(v[5] == root_fixv**2)
    m.addConstr(v[6] == root_fixv**2)
    m.addConstr(v[7] == root_fixv**2)
    m.addConstr(v[8] == root_fixv**2)
    m.addConstr(v[9] == root_fixv**2)
    m.addConstrs(v[i] >= 0.81 for i in v_list)
    m.addConstrs(v[i] <= 1.21 for i in v_list)

    # —————————————————————————————————— HV-MV变压器支路————————————————————————————————————————#
    # 假设是纯感抗支路
    u_list = [i for i in range(60, 290)]  # 1MV节点
    u = m.addVars(u_list, name='u')

    I_sub1 = m.addVar(lb=0, ub=20)
    p_sub1 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY)
    q_sub1 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY)
    # tap1 = m.addVar(lb=-5, ub=5, vtype=grb.GRB.INTEGER)
    m.addConstr(I_sub1 * v[18] >= p_sub1 ** 2 + q_sub1 ** 2)
    m.addConstr(v[18] - u[60] * (1 + 0.01 * tap1) * (1 + 0.01 * tap1) == 2 * (0.001 * q_sub1) - 0.001 * 0.001 * I_sub1)
    m.addConstr(p_sub1 + p.sum(18, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 18)) == 0)
    m.addConstr(q_sub1 + q.sum(18, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 18)) == 0)

    I_sub2 = m.addVar(lb=0, ub=20)
    p_sub2 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY)
    q_sub2 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY)
    # tap2 = m.addVar(lb=-5, ub=5, vtype=grb.GRB.INTEGER)
    m.addConstr(I_sub2 * v[30] >= p_sub2 ** 2 + q_sub2 ** 2)
    m.addConstr(v[30] - u[105] * (1 + 0.01 * tap2) ** 2 == 2 * (0.001 * q_sub2) - 0.001 * 0.001 * I_sub2)
    m.addConstr(p_sub2 + p.sum(30, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 30)) == 0)
    m.addConstr(q_sub2 + q.sum(30, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 30)) == 0)

    I_sub3 = m.addVar(lb=0, ub=20)
    p_sub3 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY)
    q_sub3 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY)
    # tap3 = m.addVar(lb=-5, ub=5, vtype=grb.GRB.INTEGER)
    m.addConstr(I_sub3 * v[41] >= p_sub3 ** 2 + q_sub3 ** 2)
    m.addConstr(v[41] - u[160] * (1 + 0.01 * tap3) ** 2 == 2 * (0.001 * q_sub3) - 0.001 * 0.001 * I_sub3)
    m.addConstr(p_sub3 + p.sum(41, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 41)) == 0)
    m.addConstr(q_sub3 + q.sum(41, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 41)) == 0)

    I_sub4 = m.addVar(lb=0, ub=20)
    p_sub4 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY)
    q_sub4 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY)
    # tap4 = m.addVar(lb=-5, ub=5, vtype=grb.GRB.INTEGER)
    m.addConstr(I_sub4 * v[46] >= p_sub4 ** 2 + q_sub4 ** 2)
    m.addConstr(v[46] - u[193] * (1 + 0.01 * tap4) ** 2 == 2 * (0.001 * q_sub4) - 0.001 * 0.001 * I_sub4)
    m.addConstr(p_sub4 + p.sum(46, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 46)) == 0)
    m.addConstr(q_sub4 + q.sum(46, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 46)) == 0)

    I_sub5 = m.addVar(lb=0, ub=20)
    p_sub5 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY)
    q_sub5 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY)
    # tap5 = m.addVar(lb=-5, ub=5, vtype=grb.GRB.INTEGER)
    m.addConstr(I_sub5 * v[56] >= p_sub5 ** 2 + q_sub5 ** 2)
    m.addConstr(v[56] - u[232] * (1 + 0.01 * tap5) ** 2 == 2 * (0.001 * q_sub5) - 0.001 * 0.001 * I_sub5)
    m.addConstr(p_sub5 + p.sum(56, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 56)) == 0)
    m.addConstr(q_sub5 + q.sum(56, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 56)) == 0)

    # —————————————————————————————————— MV馈线主体部分————————————————————————————————————————#
    MV_X = m.addVars(MV_edge_list, vtype=grb.GRB.BINARY, name='MV_X')
    MV_y = m.addVars(MV_edge_list, name='MV_y')
    m.addConstrs(MV_X[i, j] == 1 for i, j in MV_action_list)

    MV_p = m.addVars(MV_edge_list, lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='MV_p')  # 支路有功潮流
    MV_q = m.addVars(MV_edge_list, lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='MV_q')  # 支路无功潮流
    MV_l = m.addVars(MV_edge_list, name='MV_l')  # 电流的平方

    m.addConstr(grb.quicksum(MV_X[i, j] for i, j in MV_edge_list) == 225)  # 支路状态变量约束nb-ns,nb为总节点数，ns为根节点数,230-5=225

    m.addConstr(MV_p.sum(60, '*') + MV_p_load[60] == p_sub1)
    m.addConstr(MV_q.sum(60, '*') + MV_q_load[60] + I_sub1 * 0.001 == q_sub1)
    m.addConstr(MV_p.sum(105, '*') + MV_p_load[105] == p_sub2)
    m.addConstr(MV_q.sum(105, '*') + MV_q_load[105] + I_sub2 * 0.001 == q_sub2)
    m.addConstr(MV_p.sum(160, '*') + MV_p_load[160] == p_sub3)
    m.addConstr(MV_q.sum(160, '*') + MV_q_load[160] + I_sub3 * 0.001 == q_sub3)
    m.addConstr(MV_p.sum(193, '*') + MV_p_load[193] == p_sub4)
    m.addConstr(MV_q.sum(193, '*') + MV_q_load[193] + I_sub4 * 0.001 == q_sub4)
    m.addConstr(MV_p.sum(232, '*') + MV_p_load[232] == p_sub5)
    m.addConstr(MV_q.sum(232, '*') + MV_q_load[232] + I_sub5 * 0.001 == q_sub5)

    MV_pv_re = m.addVars(u_list, name='MV_pv_re')  # 光伏无功出力
    MV_pv_ac = m.addVars(u_list, name='MV_pv_re')  # 光伏有功出力
    for k in range(60, 290):
        if (k in MV_pv_list):
            m.addConstr(MV_pv_ac[k] >= 0.95 * MV_pv[k] * pv_curve_time)
            m.addConstr(MV_pv_ac[k] <= MV_pv[k] * pv_curve_time)
            # m.addConstr((MV_pv_re[k] <= 0.31 * MV_pv_ac[k]))
            # m.addConstr((MV_pv_re[k] >= -0.31 * MV_pv_ac[k]))
            m.addConstr((MV_pv_re[k] ** 2 + (MV_pv_ac[k]) ** 2 <= (theta * MV_pv[k]) ** 2))
        else:
            m.addConstr(MV_pv_ac[k] == 0)
            m.addConstr(MV_pv_re[k] == 0)

    m.addConstrs(MV_p.sum(k, '*') - grb.quicksum(MV_p[i, j] - MV_r[i, j] * MV_l[i, j] for i, j in MV_edge_list.select('*', k)) +MV_p_load[k] - MV_pv_ac[k] == 0 for k in range(61, 105))
    m.addConstrs(MV_q.sum(k, '*') - grb.quicksum(MV_q[i, j] - MV_x[i, j] * MV_l[i, j] for i, j in MV_edge_list.select('*', k)) + MV_q_load[k] - MV_pv_re[k] == 0 for k in range(61, 105))
    m.addConstrs(MV_p.sum(k, '*') - grb.quicksum(MV_p[i, j] - MV_r[i, j] * MV_l[i, j] for i, j in MV_edge_list.select('*', k)) + MV_p_load[k] - MV_pv_ac[k] == 0 for k in range(106, 160))
    m.addConstrs(MV_q.sum(k, '*') - grb.quicksum(MV_q[i, j] - MV_x[i, j] * MV_l[i, j] for i, j in MV_edge_list.select('*', k)) +MV_q_load[k] - MV_pv_re[k] == 0 for k in range(106, 160))
    m.addConstrs( MV_p.sum(k, '*') - grb.quicksum(MV_p[i, j] - MV_r[i, j] * MV_l[i, j] for i, j in MV_edge_list.select('*', k)) +MV_p_load[k] - MV_pv_ac[k] == 0 for k in range(161, 193))
    m.addConstrs(MV_q.sum(k, '*') - grb.quicksum(MV_q[i, j] - MV_x[i, j] * MV_l[i, j] for i, j in MV_edge_list.select('*', k)) +MV_q_load[k] - MV_pv_re[k] == 0 for k in range(161, 193))
    m.addConstrs(MV_p.sum(k, '*') - grb.quicksum(MV_p[i, j] - MV_r[i, j] * MV_l[i, j] for i, j in MV_edge_list.select('*', k)) +MV_p_load[k] - MV_pv_ac[k] == 0 for k in range(194, 232))
    m.addConstrs(MV_q.sum(k, '*') - grb.quicksum(MV_q[i, j] - MV_x[i, j] * MV_l[i, j] for i, j in MV_edge_list.select('*', k)) + MV_q_load[k] - MV_pv_re[k] == 0 for k in range(194, 232))
    m.addConstrs(MV_p.sum(k, '*') - grb.quicksum(MV_p[i, j] - MV_r[i, j] * MV_l[i, j] for i, j in MV_edge_list.select('*', k)) +MV_p_load[k] - MV_pv_ac[k] == 0 for k in range(233, 290))
    m.addConstrs(MV_q.sum(k, '*') - grb.quicksum(MV_q[i, j] - MV_x[i, j] * MV_l[i, j] for i, j in MV_edge_list.select('*', k)) +MV_q_load[k] - MV_pv_re[k] == 0 for k in range(233, 290))

    # 大M法约束
    m.addConstrs(MV_X[i, j] * M >= MV_p[i, j] for i, j in MV_edge_list)
    m.addConstrs(MV_p[i, j] >= -MV_X[i, j] * M for i, j in MV_edge_list)
    m.addConstrs(MV_X[i, j] * M >= MV_q[i, j] for i, j in MV_edge_list)
    m.addConstrs(MV_q[i, j] >= -MV_X[i, j] * M for i, j in MV_edge_list)

    m.addConstrs(MV_y[i, j] == (1 - MV_X[i, j]) * M for i, j in MV_edge_list)
    m.addConstrs(u[i] - u[j] <= MV_y[i, j] + 2 * (MV_r[i, j] * MV_p[i, j] + MV_x[i, j] * MV_q[i, j]) - ( MV_r[i, j] ** 2 + MV_x[i, j] ** 2) * MV_l[i, j] for i, j in MV_edge_list)
    m.addConstrs(u[i] - u[j] >= -MV_y[i, j] + 2 * (MV_r[i, j] * MV_p[i, j] + MV_x[i, j] * MV_q[i, j]) - (MV_r[i, j] ** 2 + MV_x[i, j] ** 2) * MV_l[i, j] for i, j in MV_edge_list)

    m.addConstrs(MV_l[i, j] * u[i] >= (MV_p[i, j] ** 2 + MV_q[i, j] ** 2) for i, j in MV_edge_list)
    m.addConstrs(u[i] >= 0.81 for i in u_list)
    m.addConstrs(u[i] <= 1.21 for i in u_list)

    obj = m.addVar()
    # m.addConstr(obj == grb.quicksum(r[i, j] * l[i, j] for i, j in edge_list) + grb.quicksum(MV_r[i, j] * MV_l[i, j] for i, j in MV_edge_list))
    m.addConstr(obj >= grb.quicksum(0.3 * r[i, j] * l[i, j] for i, j in edge_list) + grb.quicksum(0.3 * MV_r[i, j] * MV_l[i, j] for i, j in MV_edge_list) +
                grb.quicksum(0.7 * (v[i] - 1) ** 2 for i in range(10, 60)) + grb.quicksum(0.7 * (u[i] - 1) ** 2 for i in range(60, 290)))
    m.setObjective(obj, grb.GRB.MINIMIZE)
    # m.setObjective(grb.quicksum(r[i, j] * l[i, j] for i, j in edge_list) + grb.quicksum(MV_r[i, j] * MV_l[i, j] for i, j in MV_edge_list))
    m.setParam('OutputFlag', 0)
    m.optimize()
    voltage = np.zeros((1, 56))  # 节点4-59
    Pload= np.zeros((1, 56))
    Qload = np.zeros((1, 56))
    PPV = np.zeros((1, 56))
    branch = np.zeros((1, 56))  # HV支路

    voltage_mv = np.zeros((1, 230))  # 节点60-289
    mv_Pload = np.zeros((1, 230))
    mv_Qload = np.zeros((1, 230))
    mv_PPV = np.zeros((1, 230))
    mv_branch = np.zeros((1, 239))  # MV支路

    if m.status == grb.GRB.Status.OPTIMAL or m.status == grb.GRB.Status.SUBOPTIMAL:
        branch_index = 0
        mv_branch_index = 0
        ############################ HV ################################
        voltage[0, 4 - 3 - 1] = root_fixv**2
        voltage[0, 5 - 3 - 1] = root_fixv**2
        voltage[0, 6 - 3 - 1] = root_fixv**2
        voltage[0, 7 - 3 - 1] = root_fixv**2
        voltage[0, 8 - 3 - 1] = root_fixv**2
        voltage[0, 9 - 3 - 1] = root_fixv**2
        for i in range(10 - 4, 60 - 4):
            voltage[0, i] = v[i + 4].x
            PPV[0,i] = pv_ac[i+4].x

        for key, value in p_load.items():
            Pload[0,key-4]=value

        for key, value in q_load.items():
            Qload[0,key-4]=value

        for i, j in edge_list:
            branch[0, branch_index] = X[i, j].x
            branch_index = branch_index + 1

        ############################ MV ################################
        for i in range(230):
            voltage_mv[0, i] = u[i + 60].x
            mv_PPV[0, i] = MV_pv_ac[i + 60].x

        for key, value in MV_p_load.items():
            mv_Pload[0, key - 60] = value

        for key, value in MV_q_load.items():
            mv_Qload[0, key - 60] = value

        for i, j in MV_edge_list:
            mv_branch[0, mv_branch_index] = MV_X[i, j].x
            mv_branch_index = mv_branch_index + 1

        # print(np.sqrt(voltage_mv))
        return np.sqrt(voltage), Pload, Qload, PPV, branch, np.sqrt(voltage_mv), mv_Pload, mv_Qload, mv_PPV, mv_branch,obj.x

    else:
        # print("不可解")
        Pload = np.zeros((1, 56))
        Qload = np.zeros((1, 56))
        PPV = np.zeros((1, 56))
        mv_Pload = np.zeros((1, 230))
        mv_Qload = np.zeros((1, 230))
        mv_PPV = np.zeros((1, 230))
        # for i in range(10 - 4, 60 - 4):
        #     PPV[0,i] = pv[i+4] * pv_curve_time

        for key, value in p_load.items():
            Pload[0,key-4]=value

        for key, value in q_load.items():
            Qload[0,key-4]=value

        #######################################################
        # for i in range(230):
        #     mv_PPV[0, i] = MV_pv[i+60]* pv_curve_time

        for key, value in MV_p_load.items():
            mv_Pload[0, key - 60] = value

        for key, value in MV_q_load.items():
            mv_Qload[0, key - 60] = value

        return np.zeros((1, 56)), Pload, Qload, np.zeros((1, 56)), np.zeros((1, 56)), np.zeros((1, 230)), mv_Pload, mv_Qload, np.zeros((1, 230)), np.zeros((1, 239)),1