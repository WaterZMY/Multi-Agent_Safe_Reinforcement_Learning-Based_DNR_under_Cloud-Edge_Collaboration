import torch

def OLTC_Mask_main(num_action,current_tap,tap_max):

    # 定义 OLTC 动作集，从 -5 到 5
    oltcs = torch.arange(-(num_action-1)/2, (num_action-1)/2+1)

    # 假设当前的 OLTC 动作
    current_action = current_tap  # 当前 OLTC 动作
    max_move = tap_max  # 最大允许的移动档位数

    # 生成掩码，确保下一个动作与当前动作的差值不超过最大移动数
    mask = torch.abs(oltcs - current_action) <= max_move
    mask = mask.float()  # 将布尔值转换为浮点型（True -> 1, False -> 0）
    # 筛选出合法的 OLTC 动作
    # valid_actions = oltcs[mask]
    # print("合法的 OLTC 动作：", valid_actions)
    return mask


